# Not used (minify is disabled). Kept for completeness.
-keep class com.google.mediapipe.** { *; }
-keep class com.rafiqi.app.** { *; }
