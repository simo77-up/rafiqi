package com.rafiqi.app;

import android.content.Context;

import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Thin wrapper around the MediaPipe on-device LLM runtime.
 * Everything runs locally; the model file lives in the app's private storage.
 */
final class LlmEngine {

    interface Listener {
        void onToken(String id, String partial, boolean done);

        void onError(String id, String message);

        void onState(String state, String detail);
    }

    /** Total context (prompt + answer) the bundled Qwen2.5-0.5B ".task" file was exported with. */
    static final int MAX_TOKENS = 1280;

    private final Context context;
    private final Listener listener;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Object loadLock = new Object();

    private volatile LlmInference llm;
    private volatile boolean busy = false;
    private volatile String currentId = "";

    LlmEngine(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    File modelFile() {
        File dir = new File(context.getFilesDir(), "models");
        if (!dir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        }
        return new File(dir, "model.task");
    }

    boolean isInstalled() {
        File f = modelFile();
        return f.exists() && f.length() > 10L * 1024L * 1024L;
    }

    boolean isBusy() {
        return busy;
    }

    boolean isLoaded() {
        return llm != null;
    }

    /** Loads the model on a background thread (takes several seconds on a phone). */
    void loadAsync() {
        executor.execute(() -> {
            try {
                ensureLoaded();
            } catch (Throwable t) {
                listener.onState("error", describe(t));
            }
        });
    }

    /** Starts generating an answer. Returns false if a previous answer is still being produced. */
    synchronized boolean generate(final String id, final String prompt) {
        if (busy) {
            return false;
        }
        busy = true;
        currentId = id;
        executor.execute(() -> {
            try {
                ensureLoaded();
                llm.generateResponseAsync(prompt);
            } catch (Throwable t) {
                busy = false;
                listener.onError(id, describe(t));
            }
        });
        return true;
    }

    /** Best effort: asks the runtime to stop the current answer (ignored if unsupported). */
    void cancel() {
        try {
            if (llm != null) {
                Method m = llm.getClass().getMethod("cancelGenerateResponseAsync");
                m.invoke(llm);
            }
        } catch (Throwable ignored) {
            // Older runtime: the answer simply finishes by itself.
        }
    }

    void release() {
        synchronized (loadLock) {
            try {
                if (llm != null) {
                    llm.close();
                }
            } catch (Throwable ignored) {
                // nothing to do
            }
            llm = null;
            busy = false;
        }
    }

    boolean deleteModel() {
        release();
        return modelFile().delete();
    }

    void shutdown() {
        release();
        executor.shutdownNow();
    }

    // ------------------------------------------------------------------------------------------

    private void ensureLoaded() {
        synchronized (loadLock) {
            if (llm != null) {
                return;
            }
            File f = modelFile();
            if (!f.exists()) {
                throw new IllegalStateException("ملف النموذج غير موجود. استورده من الإعدادات أولاً.");
            }
            listener.onState("loading", "");

            LlmInferenceOptions.Builder builder = LlmInferenceOptions.builder()
                    .setModelPath(f.getAbsolutePath())
                    .setMaxTokens(MAX_TOKENS)
                    .setMaxTopK(40)
                    .setResultListener((partial, done) -> onResult(partial, done))
                    .setErrorListener(error -> onFailure(error));

            // Optional tuning: applied only when this runtime version supports it.
            trySet(builder, "setTemperature", float.class, 0.6f);
            trySetCpuBackend(builder);

            llm = LlmInference.createFromOptions(context, builder.build());
            listener.onState("ready", "");
        }
    }

    private void onResult(String partial, boolean done) {
        String id = currentId;
        if (done) {
            busy = false;
        }
        listener.onToken(id, partial == null ? "" : partial, done);
    }

    private void onFailure(Throwable error) {
        String id = currentId;
        busy = false;
        listener.onError(id, describe(error));
    }

    private static void trySet(Object builder, String name, Class<?> type, Object value) {
        try {
            Method m = LlmInferenceOptions.Builder.class.getMethod(name, type);
            m.invoke(builder, value);
        } catch (Throwable ignored) {
            // Not available in this runtime version.
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void trySetCpuBackend(Object builder) {
        try {
            Class backendClass = Class.forName(
                    "com.google.mediapipe.tasks.genai.llminference.LlmInference$Backend");
            Object cpu = Enum.valueOf(backendClass, "CPU");
            Method m = LlmInferenceOptions.Builder.class.getMethod("setPreferredBackend", backendClass);
            m.invoke(builder, cpu);
        } catch (Throwable ignored) {
            // Not available in this runtime version.
        }
    }

    static String describe(Throwable t) {
        if (t instanceof UnsatisfiedLinkError) {
            return "تعذّر تحميل مكتبة الذكاء الاصطناعي. غالباً معمارية الهاتف غير مدعومة (يلزم arm64).";
        }
        if (t instanceof OutOfMemoryError) {
            return "ذاكرة الهاتف لا تكفي لتشغيل هذا النموذج. أغلق التطبيقات الأخرى وأعد المحاولة.";
        }
        String msg = t.getMessage();
        if (msg == null || msg.isEmpty()) {
            msg = t.getClass().getSimpleName();
        }
        return msg;
    }
}
