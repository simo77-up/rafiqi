package com.rafiqi.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;

/**
 * Hosts the bundled Arabic web UI (assets/www) in a WebView and exposes a small native bridge:
 * local LLM, model import, text-to-speech, backups and a few device helpers.
 * The app declares no INTERNET permission, so nothing can leave the phone.
 */
public class MainActivity extends Activity implements LlmEngine.Listener {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";

    private static final int REQ_MODEL = 1001;
    private static final int REQ_SAVE_BACKUP = 1002;
    private static final int REQ_OPEN_BACKUP = 1003;

    private static final long MB = 1024L * 1024L;

    private WebView web;
    private LlmEngine engine;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingSpeech = null;
    private String pendingLang = "en-US";

    private String pendingBackup = null;

    // ------------------------------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        engine = new LlmEngine(this, this);

        web = new WebView(this);
        web.setBackgroundColor(0xFFF4F7F6);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse res = loader.shouldInterceptRequest(request.getUrl());
                if (res != null) {
                    return res;
                }
                // Anything that is not a bundled asset is blocked.
                return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked",
                        new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOST.equals(request.getUrl().getHost());
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl(START_URL);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            engine.shutdown();
        } catch (Throwable ignored) {
            // ignore
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------------------------------
    // Native -> JS events
    // ------------------------------------------------------------------------------------------

    private static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) {
                o.put(String.valueOf(kv[i]), kv[i + 1]);
            }
        } catch (JSONException ignored) {
            // keys are plain strings; cannot happen
        }
        return o;
    }

    private void emit(String type, JSONObject data) {
        final String js = "window.__native&&window.__native.emit(" + JSONObject.quote(type) + ","
                + (data == null ? "null" : data.toString()) + ");";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(js, null);
                }
            }
        });
    }

    @Override
    public void onToken(String id, String partial, boolean done) {
        emit("token", obj("id", id, "text", partial, "done", done));
    }

    @Override
    public void onError(String id, String message) {
        emit("llmError", obj("id", id, "message", message));
    }

    @Override
    public void onState(String state, String detail) {
        emit("llmState", obj("state", state, "detail", detail));
    }

    // ------------------------------------------------------------------------------------------
    // Activity results (file pickers)
    // ------------------------------------------------------------------------------------------

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_MODEL) {
                emit("modelImport", obj("status", "cancelled"));
            }
            pendingBackup = null;
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_MODEL) {
            importModel(uri);
        } else if (requestCode == REQ_SAVE_BACKUP) {
            writeBackup(uri);
        } else if (requestCode == REQ_OPEN_BACKUP) {
            readBackup(uri);
        }
    }

    private long sizeOf(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !c.isNull(i)) {
                    return c.getLong(i);
                }
            }
        } catch (Exception ignored) {
            // size unknown
        }
        return -1;
    }

    private void importModel(final Uri uri) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                File dest = engine.modelFile();
                File tmp = new File(dest.getParentFile(), "model.tmp");
                try {
                    long total = sizeOf(uri);
                    StatFs st = new StatFs(getFilesDir().getAbsolutePath());
                    if (total > 0 && st.getAvailableBytes() < total + 50 * MB) {
                        emit("modelImport", obj("status", "error", "message",
                                "المساحة الفارغة لا تكفي. تحتاج نحو " + ((total + 50 * MB) / MB)
                                        + " ميغابايت فارغة."));
                        return;
                    }
                    emit("modelImport", obj("status", "progress", "pct", 0, "mb", 0));
                    engine.release();

                    try (InputStream in = getContentResolver().openInputStream(uri);
                         OutputStream out = new FileOutputStream(tmp)) {
                        if (in == null) {
                            throw new IOException("تعذّر فتح الملف");
                        }
                        byte[] buf = new byte[(int) MB];
                        long done = 0;
                        int lastPct = -1;
                        long lastMb = -1;
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            done += n;
                            int pct = total > 0 ? (int) (done * 100 / total) : -1;
                            long mb = done / MB;
                            if (pct != lastPct || (total <= 0 && mb != lastMb)) {
                                lastPct = pct;
                                lastMb = mb;
                                emit("modelImport", obj("status", "progress", "pct", pct, "mb", mb));
                            }
                        }
                        out.flush();
                    }

                    if (tmp.length() < 10 * MB) {
                        //noinspection ResultOfMethodCallIgnored
                        tmp.delete();
                        emit("modelImport", obj("status", "error", "message",
                                "الملف صغير جداً، ولا يبدو ملف نموذج صالحاً."));
                        return;
                    }
                    if (dest.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        dest.delete();
                    }
                    if (!tmp.renameTo(dest)) {
                        throw new IOException("تعذّر حفظ الملف");
                    }
                    emit("modelImport", obj("status", "done", "mb", dest.length() / MB));
                } catch (Throwable t) {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                    emit("modelImport", obj("status", "error", "message", LlmEngine.describe(t)));
                }
            }
        }).start();
    }

    private void writeBackup(final Uri uri) {
        final String json = pendingBackup;
        pendingBackup = null;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null || json == null) {
                        throw new IOException("تعذّر الكتابة");
                    }
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    emit("backupSaved", obj("ok", true));
                } catch (Throwable t) {
                    emit("backupSaved", obj("ok", false, "message", LlmEngine.describe(t)));
                }
            }
        }).start();
    }

    private void readBackup(final Uri uri) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) {
                        throw new IOException("تعذّر فتح الملف");
                    }
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    long total = 0;
                    while ((n = in.read(buf)) > 0) {
                        total += n;
                        if (total > 30 * MB) {
                            throw new IOException("الملف كبير جداً");
                        }
                        bos.write(buf, 0, n);
                    }
                    emit("backupData", obj("ok", true, "json", new String(bos.toByteArray(), StandardCharsets.UTF_8)));
                } catch (Throwable t) {
                    emit("backupData", obj("ok", false, "message", LlmEngine.describe(t)));
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------------------------------
    // Text to speech
    // ------------------------------------------------------------------------------------------

    private void speakOnUi(final String text, final String lang) {
        if (tts == null) {
            pendingSpeech = text;
            pendingLang = lang;
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    ttsReady = (status == TextToSpeech.SUCCESS);
                    if (!ttsReady) {
                        emit("tts", obj("error", "init"));
                        return;
                    }
                    tts.setSpeechRate(0.9f);
                    if (pendingSpeech != null) {
                        doSpeak(pendingSpeech, pendingLang);
                        pendingSpeech = null;
                    }
                }
            });
        } else if (ttsReady) {
            doSpeak(text, lang);
        } else {
            pendingSpeech = text;
            pendingLang = lang;
        }
    }

    private void doSpeak(String text, String lang) {
        int r = tts.setLanguage(Locale.forLanguageTag(lang));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            emit("tts", obj("error", "lang"));
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rafiqi");
    }

    // ------------------------------------------------------------------------------------------
    // JS -> native bridge (window.Android)
    // ------------------------------------------------------------------------------------------

    private class Bridge {

        @JavascriptInterface
        public String getInfo() {
            JSONObject o = new JSONObject();
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                if (am != null) {
                    am.getMemoryInfo(mi);
                }
                StatFs st = new StatFs(getFilesDir().getAbsolutePath());
                File mf = engine.modelFile();
                JSONArray abis = new JSONArray();
                for (String a : Build.SUPPORTED_ABIS) {
                    abis.put(a);
                }
                o.put("modelInstalled", engine.isInstalled());
                o.put("modelMB", mf.exists() ? mf.length() / MB : 0);
                o.put("loaded", engine.isLoaded());
                o.put("busy", engine.isBusy());
                o.put("abis", abis);
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("device", Build.MANUFACTURER + " " + Build.MODEL);
                o.put("totalRamMB", mi.totalMem / MB);
                o.put("availRamMB", mi.availMem / MB);
                o.put("freeMB", st.getAvailableBytes() / MB);
                o.put("version", "1.0");
            } catch (Throwable ignored) {
                // return what we have
            }
            return o.toString();
        }

        @JavascriptInterface
        public void pickModel() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        startActivityForResult(i, REQ_MODEL);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "لا يوجد تطبيق لاختيار الملفات", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void loadModel() {
            engine.loadAsync();
        }

        @JavascriptInterface
        public boolean deleteModel() {
            return engine.deleteModel();
        }

        @JavascriptInterface
        public boolean generate(String id, String prompt) {
            return engine.generate(id, prompt);
        }

        @JavascriptInterface
        public void cancel() {
            engine.cancel();
        }

        @JavascriptInterface
        public void speak(final String text, final String lang) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    speakOnUi(text, lang == null || lang.isEmpty() ? "en-US" : lang);
                }
            });
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (tts != null) {
                        tts.stop();
                    }
                }
            });
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                v.vibrate(VibrationEffect.createOneShot(Math.max(20, Math.min(ms, 2000)),
                        VibrationEffect.DEFAULT_AMPLITUDE));
            }
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on) {
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "مشاركة"));
                }
            });
        }

        @JavascriptInterface
        public void saveBackup(final String json, final String filename) {
            pendingBackup = json;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/json");
                        i.putExtra(Intent.EXTRA_TITLE, filename);
                        startActivityForResult(i, REQ_SAVE_BACKUP);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "لا يوجد تطبيق لحفظ الملفات", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void pickBackup() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        startActivityForResult(i, REQ_OPEN_BACKUP);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "لا يوجد تطبيق لاختيار الملفات", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
