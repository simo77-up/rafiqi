'use strict';
Views.english = {
  title: 'تعلّم الإنجليزية',
  render(el, rest) {
    let tab = rest[0] || 'cards', cat = 'all', gId = null;
    const TABS_ = [['cards', 'بطاقات'], ['phrases', 'عبارات'], ['grammar', 'قواعد'], ['quiz', 'اختبار']];
    const items = () => VOCAB.filter(v => cat === 'all' || v.cat === cat).map(v => ({ id: v.id, front: v.en, back: v.ar, ex: v.ex, tag: v.catName + ' · ' + POS_AR[v.pos], speak: v.en }));
    const shell = () => { el.innerHTML = `<div class="seg">${TABS_.map(t => `<button data-t="${t[0]}" class="${t[0] === tab ? 'on' : ''}">${t[1]}</button>`).join('')}</div><div id="body"></div>`; };
    const body = () => $('#body', el);

    function cards() {
      const its = items(); const c = SRS.counts(its);
      const allowed = Math.max(0, Settings.get('newPerDay') - Stats.today('newWords'));
      const todayN = c.due + Math.min(c.fresh, allowed);
      body().innerHTML = `
        <div class="grid3 mb"><div class="stat"><b>${c.due}</b><span>للمراجعة</span></div><div class="stat"><b>${c.fresh}</b><span>جديدة</span></div><div class="stat"><b>${c.mastered}</b><span>متقنة</span></div></div>
        <div class="chips"><button class="chip ${cat === 'all' ? 'on' : ''}" data-c="all">الكل</button>${VOCAB_CATS.map(k => `<button class="chip ${cat === k.id ? 'on' : ''}" data-c="${k.id}">${k.name}</button>`).join('')}</div>
        <button class="btn block" data-a="start" ${todayN ? '' : 'disabled'}>${icon('cards')} ابدأ المراجعة (${todayN})</button>
        ${!todayN && c.fresh ? `<button class="btn ghost block mt-s" data-a="more">تعلّم 10 كلمات إضافية</button>` : ''}
        <div class="card mt"><h3>قائمة الكلمات (${its.length})</h3>${its.map(w => `<div class="phrase"><div class="grow"><div class="en">${esc(w.front)}</div><div class="ar">${esc(w.back)}</div></div>
          <button class="round-btn plain" data-say="${esc(w.front)}" aria-label="نطق">${icon('speaker')}</button></div>`).join('')}</div>`;
    }
    function phrases() {
      body().innerHTML = PHRASES.map(g => `<div class="card"><h3>${g.cat}</h3>${g.items.map(p => `<div class="phrase"><div class="grow"><div class="en">${esc(p[0])}</div><div class="ar">${esc(p[1])}</div></div>
        <button class="round-btn plain" data-say="${esc(p[0])}" aria-label="نطق">${icon('speaker')}</button></div>`).join('')}</div>`).join('');
    }
    function grammar() {
      if (!gId) {
        const done = Store.get('gramDone', {});
        body().innerHTML = `<div class="card">${GRAMMAR.map((g, i) => `<button class="lesson-row" data-g="${g.id}"><span class="num ${done[g.id] ? 'done' : ''}">${done[g.id] ? icon('check', 18) : i + 1}</span><span class="grow"><b>${g.title}</b></span>${icon('back')}</button>`).join('')}</div>`;
        return;
      }
      const g = GRAMMAR.find(x => x.id === gId); let answered = 0, right = 0;
      body().innerHTML = `<button class="btn sm ghost mb" data-a="gback">رجوع للقائمة</button>
        <div class="card"><h3>${g.title}</h3>${g.body.map(p => `<p>${p}</p>`).join('')}</div>
        <div class="card"><h3>أمثلة</h3>${g.ex.map(x => `<div class="ex-line row"><div class="grow"><div class="en">${esc(x[0])}</div><div class="ar">${esc(x[1])}</div></div><button class="round-btn plain" data-say="${esc(x[0])}">${icon('speaker')}</button></div>`).join('')}</div>
        <div class="card"><h3>اختبر نفسك</h3>${g.quiz.map((q, qi) => `<div class="mb"><div class="ltr" style="font-weight:700;margin-bottom:6px">${esc(q[0])}</div>${q[1].map((o, oi) => `<button class="opt ltr-text" data-q="${qi}" data-o="${oi}">${esc(o)}</button>`).join('')}</div>`).join('')}<div id="gres" class="center muted"></div></div>`;
      body().onclick = e => {
        const o = e.target.closest('[data-q]'); if (!o || o.parentElement.dataset.done) return;
        const q = g.quiz[+o.dataset.q], ok = +o.dataset.o === q[2];
        o.parentElement.dataset.done = 1; answered++; if (ok) right++;
        o.classList.add(ok ? 'ok' : 'no');
        if (!ok) o.parentElement.querySelectorAll('.opt')[q[2]].classList.add('ok');
        if (answered === g.quiz.length) { $('#gres', el).textContent = `النتيجة: ${right} من ${answered}`; if (right >= Math.ceil(answered * .6)) { const d = Store.get('gramDone', {}); d[g.id] = 1; Store.set('gramDone', d); } Stats.mark(); }
      };
    }
    let quiz = null;
    function quizTab() {
      if (!quiz) {
        body().innerHTML = `<div class="card center"><h3>اختبار المفردات</h3><p class="muted">10 أسئلة: اختر المعنى الصحيح.</p>
          <p class="small">أفضل نتيجة: <b>${Store.get('stats', {}).quizBest || 0}</b> / 10</p><button class="btn block" data-a="qstart">ابدأ الاختبار</button></div>`;
        return;
      }
      if (quiz.i >= quiz.qs.length) {
        const d = Stats.data(); d.quizzes = (d.quizzes || 0) + 1; d.quizBest = Math.max(d.quizBest || 0, quiz.score); Stats.save(d); Stats.mark();
        body().innerHTML = `<div class="card center"><div style="font-size:3rem">${quiz.score >= 8 ? '🏆' : quiz.score >= 5 ? '👍' : '💪'}</div><h3>نتيجتك ${quiz.score} / ${quiz.qs.length}</h3>
          <button class="btn block mt" data-a="qstart">اختبار جديد</button></div>`; quiz = null; return;
      }
      const q = quiz.qs[quiz.i];
      body().innerHTML = `<div class="row between mb"><span class="muted small">${quiz.i + 1} / ${quiz.qs.length}</span><span class="badge">${quiz.score} صحيحة</span></div>
        <div class="progress mb"><i style="width:${quiz.i * 10}%"></i></div>
        <div class="card"><div class="q-text en">${esc(q.word.en)}</div><div class="center mb"><button class="round-btn" data-say="${esc(q.word.en)}">${icon('speaker')}</button></div>
        ${q.opts.map((o, i) => `<button class="opt" data-qo="${i}">${esc(o.ar)}</button>`).join('')}</div>`;
    }
    function draw() { shell(); body().onclick = null; ({ cards, phrases, grammar, quiz: quizTab }[tab] || cards)(); }

    el.onclick = e => {
      const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; gId = null; draw(); return; }
      const c = e.target.closest('[data-c]'); if (c) { cat = c.dataset.c; cards(); return; }
      const s = e.target.closest('[data-say]'); if (s) { speak(s.dataset.say); return; }
      const g = e.target.closest('[data-g]'); if (g) { gId = g.dataset.g; grammar(); el.scrollTop = 0; $('#view').scrollTop = 0; return; }
      const a = e.target.closest('[data-a]');
      if (a) {
        const k = a.dataset.a;
        if (k === 'start' || k === 'more') { body().innerHTML = '<div id="sess"></div>'; SRS.mount($('#sess', el), { items: items(), newLimit: Settings.get('newPerDay'), forceNew: k === 'more', onDone: draw, autoSpeakOnReveal: false }); }
        else if (k === 'gback') { gId = null; grammar(); }
        else if (k === 'qstart') {
          const qs = shuffle(VOCAB).slice(0, 10).map(w => ({ word: w, opts: shuffle([w].concat(shuffle(VOCAB.filter(x => x.id !== w.id && x.pos === w.pos)).slice(0, 3))) }));
          quiz = { qs, i: 0, score: 0 }; quizTab();
        }
        return;
      }
      const qo = e.target.closest('[data-qo]');
      if (qo && quiz) {
        const q = quiz.qs[quiz.i], ok = q.opts[+qo.dataset.qo].id === q.word.id;
        $$('.opt', el).forEach((b, i) => { b.disabled = true; if (q.opts[i].id === q.word.id) b.classList.add('ok'); });
        if (!ok) qo.classList.add('no'); else quiz.score++;
        SRS.grade(q.word.id, ok);
        setTimeout(() => { if (quiz) { quiz.i++; quizTab(); } }, 900);
      }
    };
    draw();
  }
};
