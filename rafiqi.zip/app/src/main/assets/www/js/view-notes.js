'use strict';
Views.notes = {
  title: 'الملاحظات',
  render(el, rest) {
    let q = '';
    const load = () => Store.get('notes', []);
    const save = n => Store.set('notes', n);

    function list() {
      el.className = ''; $('#title').textContent = 'الملاحظات';
      const all = load().filter(n => !q || (n.title + ' ' + n.body).toLowerCase().includes(q.toLowerCase()))
        .sort((a, b) => (b.pinned - a.pinned) || (b.updated - a.updated));
      el.innerHTML = `<input type="search" id="nq" placeholder="بحث في الملاحظات…" value="${esc(q)}" class="mb">
        ${all.length ? all.map(n => `<button class="note-card" data-open="${n.id}"><h4>${n.pinned ? icon('pin', 16) : ''}${esc(n.title || 'بدون عنوان')}</h4><p>${esc(n.body.slice(0, 160) || '…')}</p><div class="tiny muted mt-s">${relTime(n.updated)}</div></button>`).join('')
          : `<div class="empty">${icon('notes')}<p>${q ? 'لا نتائج.' : 'لا توجد ملاحظات بعد. اضغط + لإضافة أول ملاحظة.'}</p></div>`}
        <button class="fab" data-new aria-label="ملاحظة جديدة">${icon('plus')}</button>`;
      el.style.position = 'relative';
      const inp = $('#nq', el); inp.oninput = ev => { q = ev.target.value; const pos = inp.selectionStart; list(); const n2 = $('#nq', el); n2.focus(); n2.setSelectionRange(pos, pos); };
    }
    function edit(id) {
      const all = load(); let n = all.find(x => x.id === id);
      if (!n) { n = { id: uid(), title: '', body: '', tags: [], pinned: false, created: Date.now(), updated: Date.now() }; all.unshift(n); save(all); location.replace('#/notes/' + n.id); }
      $('#title').textContent = 'تحرير ملاحظة';
      el.innerHTML = `<div class="card" style="display:flex;flex-direction:column;min-height:70%">
        <input type="text" class="note-title-in" id="nt" placeholder="العنوان" value="${esc(n.title)}" maxlength="80">
        <textarea class="note-body-in" id="nb" placeholder="اكتب ملاحظتك هنا…">${esc(n.body)}</textarea>
        <div class="tiny muted" id="ns">يُحفظ تلقائياً</div></div>
        <div class="grid3"><button class="btn ghost" data-a="pin">${icon('pin')} ${n.pinned ? 'إلغاء التثبيت' : 'تثبيت'}</button><button class="btn ghost" data-a="share">${icon('share')} مشاركة</button><button class="btn danger ghost" data-a="del">${icon('trash')} حذف</button></div>
        <button class="btn block mt" data-a="back">تم</button>`;
      const persist = debounce(() => { const a = load(); const m = a.find(x => x.id === n.id); if (!m) return; m.title = $('#nt', el) ? $('#nt', el).value : m.title; m.body = $('#nb', el) ? $('#nb', el).value : m.body; m.updated = Date.now(); save(a); const s = $('#ns', el); if (s) s.textContent = 'تم الحفظ ✓'; }, 500);
      $('#nt', el).oninput = persist; $('#nb', el).oninput = persist;
      el.onclick = async e => {
        const a = e.target.closest('[data-a]'); if (!a) return; persist.flush();
        const k = a.dataset.a;
        if (k === 'back') location.hash = '#/notes';
        else if (k === 'pin') { const arr = load(); const m = arr.find(x => x.id === n.id); m.pinned = !m.pinned; save(arr); edit(n.id); }
        else if (k === 'share') { const t = ($('#nt', el).value ? $('#nt', el).value + '\n\n' : '') + $('#nb', el).value; if (Native.available) Native.call('shareText', t); else copyText(t); }
        else if (k === 'del') { if (await confirmDlg('حذف الملاحظة', 'لا يمكن التراجع عن الحذف.', 'حذف', true)) { save(load().filter(x => x.id !== n.id)); location.hash = '#/notes'; } }
      };
    }

    if (rest[0]) { if (rest[0] === 'new') edit('new'); else edit(rest[0]); }
    else {
      list();
      el.onclick = e => { const o = e.target.closest('[data-open]'); if (o) location.hash = '#/notes/' + o.dataset.open; else if (e.target.closest('[data-new]')) location.hash = '#/notes/new'; };
    }
  }
};
