'use strict';
/* Local assistant: talks to the on-device model through the native bridge (no network),
   and falls back to a small rule-based helper ("simple mode") when no model is installed. */

const AI_MODES = {
  general: { name: 'عام', hint: 'اسألني أي شيء…', system: 'You are Rafiqi (رفيقي), a friendly offline assistant. Answer in clear Modern Standard Arabic unless the user writes in English. Be concise: at most 5 short sentences. If you are not sure, say so.' },
  english: { name: 'مدرّس إنجليزي', hint: 'اكتب بالإنجليزية لأصحّح لك…', system: 'You are a friendly English tutor for an Arabic speaker. Reply in simple English first, then add a short Arabic explanation. Gently correct mistakes in the user\'s English. Keep it short.' },
  study: { name: 'مساعد دراسة', hint: 'ما الذي تدرسه اليوم؟', system: 'You are a study coach. Explain ideas simply in Arabic with short steps or a small example. Keep answers brief and encouraging.' },
  code: { name: 'مبرمج', hint: 'اسأل عن كود أو خطأ…', system: 'You are a programming helper. Explain in Arabic, but keep code and identifiers in English. Show short code examples. Be concise.' }
};

const AI = {
  info: null,
  state: 'idle',          // idle | loading | ready | error
  stateDetail: '',
  nativeBusy: false,
  cur: null,
  listeners: [],

  refresh() { this.info = Native.available ? Native.info() : null; return this.info; },
  get hasNative() { return Native.available; },
  get installed() { const i = this.info || this.refresh(); return !!(i && i.modelInstalled); },
  get usable() { return this.hasNative && this.installed; },

  onChange(fn) { this.listeners.push(fn); return () => { this.listeners = this.listeners.filter(f => f !== fn); }; },
  _notify() { this.listeners.slice().forEach(f => { try { f(); } catch (e) { console.error(e); } }); },

  /** ChatML prompt (Qwen2.5). Keeps the prompt inside the model's small context window. */
  buildPrompt(mode, history, text) {
    const sys = `<|im_start|>system\n${(AI_MODES[mode] || AI_MODES.general).system}<|im_end|>\n`;
    const user = `<|im_start|>user\n${text}<|im_end|>\n<|im_start|>assistant\n`;
    let budget = 1100 - text.length;
    const parts = [];
    for (let i = history.length - 1; i >= 0 && budget > 0; i--) {
      const m = history[i];
      if (m.err || m.local || !m.text) continue;
      const t = m.text.slice(0, 600);
      budget -= t.length;
      if (budget < 0) break;
      parts.unshift(`<|im_start|>${m.role === 'user' ? 'user' : 'assistant'}\n${t}<|im_end|>\n`);
    }
    return sys + parts.join('') + user;
  },

  clean(t) {
    return String(t).replace(/<\|im_start\|>[\s\S]*$/, '').replace(/<\|im_end\|>[\s\S]*$/, '').replace(/<\|endoftext\|>[\s\S]*$/, '').replace(/^\s+/, '');
  },

  /** Ask the local model. handlers: { onToken(fullText), onStatus(msg) }. Resolves with the final text. */
  async ask(mode, history, text, handlers = {}) {
    if (!this.usable) throw new Error('النموذج غير مثبّت. افتح الإعدادات ← الذكاء الاصطناعي المحلي.');
    if (this.nativeBusy) {
      if (handlers.onStatus) handlers.onStatus('جارٍ إنهاء الرد السابق…');
      const t0 = Date.now();
      while (this.nativeBusy && Date.now() - t0 < 60000) await sleep(300);
      if (this.nativeBusy) throw new Error('النموذج ما زال مشغولاً. انتظر قليلاً ثم حاول مجدداً.');
    }
    const id = uid();
    const prompt = this.buildPrompt(mode, history, text.slice(0, 1500));
    return new Promise((resolve, reject) => {
      const cur = { id, raw: '', handlers, resolve, reject, stopped: false, gotToken: false };
      this.cur = cur;
      this.nativeBusy = true;
      const accepted = Native.call('generate', id, prompt);
      if (accepted === false) { this.nativeBusy = false; this.cur = null; reject(new Error('النموذج مشغول، حاول بعد لحظات.')); return; }
      if (handlers.onStatus) handlers.onStatus(this.state === 'ready' ? 'يفكّر…' : 'جارٍ تحميل النموذج (أول مرة قد تستغرق دقيقة)…');
      cur.watchdog = setTimeout(() => {
        if (this.cur === cur && !cur.gotToken) { this._finishCur(new Error('استغرق النموذج وقتاً طويلاً بلا ردّ. جرّب إغلاق التطبيقات الأخرى.')); }
      }, 180000);
    });
  },

  stop() {
    const c = this.cur; if (!c) return;
    c.stopped = true; Native.call('cancel');
    this._finishCur(null, true);
  },

  _finishCur(err, stoppedByUser) {
    const c = this.cur; if (!c) return;
    clearTimeout(c.watchdog);
    this.cur = null;
    if (err) c.reject(err); else c.resolve({ text: this.clean(c.raw), stopped: !!stoppedByUser });
  },

  _onToken(d) {
    if (!d) return;
    const c = this.cur;
    if (d.done && (!c || d.id !== c.id)) { this.nativeBusy = false; this._notify(); return; }
    if (!c || d.id !== c.id) return;
    c.gotToken = true; clearTimeout(c.watchdog);
    c.raw += d.text || '';
    if (c.handlers.onToken && !c.stopped) c.handlers.onToken(this.clean(c.raw));
    if (d.done || /<\|im_end\|>|<\|endoftext\|>/.test(c.raw)) {
      if (d.done) this.nativeBusy = false;
      this._finishCur(null);
      this._notify();
    }
  },

  _onError(d) {
    this.nativeBusy = false;
    const c = this.cur;
    if (c) this._finishCur(new Error((d && d.message) || 'حدث خطأ في النموذج'));
    this._notify();
  },

  _onState(d) {
    this.state = (d && d.state) || 'idle'; this.stateDetail = (d && d.detail) || '';
    if (this.state === 'error') { this.nativeBusy = false; if (this.cur) this._finishCur(new Error(this.stateDetail || 'تعذّر تشغيل النموذج')); }
    this.refresh(); this._notify();
  },

  /* ---------- simple (rule-based) helper: works with no model and no network ---------- */
  lookup(q) {
    const t = q.trim().toLowerCase(); if (!t) return [];
    const isAr = /[؀-ۿ]/.test(t);
    let res;
    if (isAr) res = VOCAB.filter(v => v.ar.replace(/[ً-ْ]/g, '').includes(t));
    else res = VOCAB.filter(v => v.en === t).concat(VOCAB.filter(v => v.en !== t && v.en.startsWith(t)));
    return res.slice(0, 5);
  },
  wordOfDay() { const n = Math.floor(parseIso(isoDate()).getTime() / 86400000); return VOCAB[n % VOCAB.length]; },

  simple(raw) {
    const text = raw.trim();
    const m = (re) => text.match(re);
    let r;
    if ((r = m(/^(?:ملاحظة|ملاحظه|دوّن|دون|سجّل|سجل)\s*[:：]?\s*([\s\S]+)/))) {
      const body = r[1].trim(); const notes = Store.get('notes', []);
      notes.unshift({ id: uid(), title: body.split('\n')[0].slice(0, 40), body, tags: [], pinned: false, created: Date.now(), updated: Date.now() });
      Store.set('notes', notes); Stats.mark();
      return { text: 'تم حفظ الملاحظة ✓', link: ['#/notes', 'فتح الملاحظات'] };
    }
    if ((r = m(/^(?:مهمة|مهمّة|أضف مهمة|اضف مهمة)\s*[:：]?\s*([\s\S]+)/))) {
      const tasks = Store.get('tasks', []);
      tasks.unshift({ id: uid(), title: r[1].trim().slice(0, 120), subject: Settings.get('subject'), due: '', pri: 1, done: false, created: Date.now() });
      Store.set('tasks', tasks);
      return { text: 'تمت إضافة المهمة ✓', link: ['#/study/tasks', 'فتح المهام'] };
    }
    if (/^(?:مهامي|المهام|ما هي مهامي|ماذا لدي اليوم)/.test(text)) {
      const open = Store.get('tasks', []).filter(t => !t.done).slice(0, 8);
      return { text: open.length ? 'مهامك الحالية:\n' + open.map(t => '- ' + t.title).join('\n') : 'لا توجد مهام معلّقة. 🎉', link: ['#/study/tasks', 'فتح المهام'] };
    }
    if ((r = m(/^(?:ترجم|ترجمة|معنى|ما معنى|ما هو معنى)\s*[:：]?\s*([\s\S]+)/)) || /^[A-Za-z][A-Za-z' -]{1,30}$/.test(text)) {
      const q = r ? r[1] : text; const found = this.lookup(q);
      if (found.length) return { text: found.map(v => `**${v.en}** = ${v.ar}\n${v.ex}`).join('\n\n'), speak: found[0].en };
      return { text: `لم أجد «${q.trim()}» في القاموس المدمج (${VOCAB.length} كلمة). ثبّت النموذج الذكي من الإعدادات لأترجم أي نص.` };
    }
    if (/كلمة اليوم/.test(text)) { const w = this.wordOfDay(); return { text: `كلمة اليوم: **${w.en}** = ${w.ar}\n${w.ex}`, speak: w.en }; }
    if (/(?:ابدأ|شغّل|شغل|ابدا).*(?:تركيز|مؤقت|بومودورو|دراسة)/.test(text)) return { text: 'لنبدأ التركيز! 💪', link: ['#/study/timer', 'فتح المؤقّت'] };
    if (/^(?:مرحبا|مرحباً|أهلا|أهلاً|السلام|هلا|صباح|مساء)/.test(text)) return { text: 'أهلاً بك! أنا رفيقي. اكتب «مساعدة» لأريك ما أستطيع فعله الآن.' };
    if (/^(?:مساعدة|ساعدني|help|ماذا تفعل|ماذا تستطيع)/i.test(text)) return { text: this.helpText() };
    return { text: 'لا أستطيع فهم هذا الطلب في **الوضع البسيط**.\nالنموذج الذكي المحلي غير مثبّت بعد، فيمكنني الآن فعل ما يلي فقط:\n' + this.helpLines(), needModel: true };
  },
  helpLines() { return '- «ملاحظة: …» لحفظ ملاحظة\n- «مهمة: …» لإضافة مهمة\n- «مهامي» لعرض المهام\n- «ترجم word» أو اكتب كلمة إنجليزية لأترجمها\n- «كلمة اليوم»\n- «ابدأ التركيز»'; },
  helpText() { return 'أنا أعمل الآن بدون نموذج ذكي (الوضع البسيط). أستطيع:\n' + this.helpLines() + '\n\nلتفعيل الذكاء الاصطناعي الكامل: الإعدادات ← الذكاء الاصطناعي المحلي.'; }
};

Native.on('token', d => AI._onToken(d));
Native.on('llmError', d => AI._onError(d));
Native.on('llmState', d => AI._onState(d));
