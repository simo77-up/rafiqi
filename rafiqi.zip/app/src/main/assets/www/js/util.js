'use strict';
/* Shared helpers: DOM, dates, icons, toast, bottom sheets, native bridge events, speech. */

const Views = {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const pad = n => String(n).padStart(2, '0');
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const sleep = ms => new Promise(r => setTimeout(r, ms));
function debounce(fn, ms) { let t; const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; d.flush = (...a) => { clearTimeout(t); fn(...a); }; return d; }
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }

/* ---------- dates ---------- */
const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const WEEKDAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
function isoDate(d = new Date()) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
function parseIso(iso) { const [y, m, d] = iso.split('-').map(Number); return new Date(y, m - 1, d); }
function addDays(iso, n) { const d = parseIso(iso); d.setDate(d.getDate() + n); return isoDate(d); }
function daysBetween(a, b) { return Math.round((parseIso(b) - parseIso(a)) / 86400000); }
function fmtDate(iso) { const d = parseIso(iso); return WEEKDAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear(); }
function fmtShort(iso) { const d = parseIso(iso); return d.getDate() + ' ' + MONTHS[d.getMonth()]; }
function relTime(ts) {
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'الآن';
  if (min < 60) return 'قبل ' + countAr(min, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة');
  const h = Math.floor(min / 60);
  if (h < 24) return 'قبل ' + countAr(h, 'ساعة', 'ساعتين', 'ساعات', 'ساعة');
  const d = new Date(ts); const today = isoDate();
  const diffDays = daysBetween(isoDate(d), today);
  if (diffDays === 1) return 'أمس';
  if (diffDays < 7) return 'قبل ' + countAr(diffDays, 'يوم', 'يومين', 'أيام', 'يوماً');
  return fmtShort(isoDate(d));
}
/** Arabic number agreement: countAr(5,'دقيقة','دقيقتين','دقائق','دقيقة') -> "5 دقائق" */
function countAr(n, one, two, few, many) {
  if (n === 1) return one;
  if (n === 2) return two;
  if (n >= 3 && n <= 10) return n + ' ' + few;
  return n + ' ' + many;
}
function mmss(sec) { sec = Math.max(0, Math.round(sec)); return pad(Math.floor(sec / 60)) + ':' + pad(sec % 60); }

/* ---------- icons (stroke style) ---------- */
const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
  english: '<path d="M4 19l5.5-13L15 19"/><path d="M6 14.5h7"/><path d="M17 9.5c1.2-.8 4-.8 4 1.5v8"/><path d="M21 14.5c-2.5-.3-4.2.4-4.2 2.2 0 1.6 1.6 2.2 4.2 1.3"/>',
  study: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5"/><path d="M22 9v6"/>',
  code: '<path d="M8 8l-5 4 5 4"/><path d="M16 8l5 4-5 4"/><path d="M14 5l-4 14"/>',
  notes: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 12h6M9 16h6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/><circle cx="12" cy="12" r="7"/>',
  send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/>',
  pin: '<path d="M12 17v5"/><path d="M9 3h6l-1 7 3 3H7l3-3z"/>',
  speaker: '<path d="M11 5L6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 10.6l6.8-4.2M8.6 13.4l6.8 4.2"/>',
  flame: '<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
  timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/>',
  back: '<path d="M9 6l6 6-6 6"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  upload: '<path d="M12 21V9M7 14l5-5 5 5M5 3h14"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 6"/><path d="M20 4v7h-7"/>',
  cards: '<rect x="3" y="6" width="14" height="14" rx="2"/><path d="M7 6V4h14v14h-2"/>',
  list: '<path d="M9 6h12M9 12h12M9 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>',
  book: '<path d="M4 4h6a3 3 0 0 1 2 1 3 3 0 0 1 2-1h6v15h-6a3 3 0 0 0-2 1 3 3 0 0 0-2-1H4z"/><path d="M12 5v15"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>'
};
function icon(name, size) {
  const s = size ? ` style="width:${size}px;height:${size}px"` : '';
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"${s} aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

/* ---------- toast ---------- */
let toastTimer;
function toast(msg, ms = 2300) {
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}

/* ---------- bottom sheets (Back button closes the top one) ---------- */
const Sheets = { stack: [] };
function sheet(content, { title = '', onClose } = {}) {
  const back = document.createElement('div');
  back.className = 'sheet-back';
  back.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="sheet-grip"></div>${title ? `<h3 class="sheet-title">${esc(title)}</h3>` : ''}<div class="sheet-body"></div></div>`;
  const body = $('.sheet-body', back);
  if (typeof content === 'string') body.innerHTML = content; else body.appendChild(content);
  $('#sheet-root').appendChild(back);
  requestAnimationFrame(() => back.classList.add('open'));
  let closed = false;
  const api = {
    el: body,
    close() { if (closed) return; if (history.state && history.state.sheet) history.back(); else api._finish(); },
    _finish() {
      if (closed) return; closed = true;
      back.classList.remove('open'); setTimeout(() => back.remove(), 200);
      Sheets.stack = Sheets.stack.filter(s => s !== api);
      if (onClose) onClose();
    }
  };
  back.addEventListener('click', e => { if (e.target === back) api.close(); });
  Sheets.stack.push(api);
  history.pushState({ sheet: true }, '');
  return api;
}
window.addEventListener('popstate', () => { const top = Sheets.stack[Sheets.stack.length - 1]; if (top) top._finish(); });

function confirmDlg(title, msg, okLabel = 'تأكيد', danger = false) {
  return new Promise(resolve => {
    let answered = false;
    const s = sheet(`<p class="muted">${esc(msg)}</p>
      <div class="grid2 mt"><button class="btn ghost" data-r="0">إلغاء</button><button class="btn ${danger ? 'danger' : ''}" data-r="1">${esc(okLabel)}</button></div>`,
      { title, onClose: () => { if (!answered) resolve(false); } });
    s.el.addEventListener('click', e => {
      const b = e.target.closest('[data-r]'); if (!b) return;
      answered = true; resolve(b.dataset.r === '1'); s.close();
    });
  });
}
function promptDlg(title, label, value = '', okLabel = 'حفظ') {
  return new Promise(resolve => {
    let answered = false;
    const s = sheet(`<label class="field"><span>${esc(label)}</span><input type="text" id="pd-in" value="${esc(value)}" autocomplete="off"></label>
      <div class="grid2"><button class="btn ghost" data-r="0">إلغاء</button><button class="btn" data-r="1">${esc(okLabel)}</button></div>`,
      { title, onClose: () => { if (!answered) resolve(null); } });
    const inp = $('#pd-in', s.el); setTimeout(() => inp.focus(), 250);
    const done = ok => { answered = true; resolve(ok ? inp.value.trim() : null); s.close(); };
    s.el.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if (b) done(b.dataset.r === '1'); });
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') done(true); });
  });
}

/* ---------- native bridge ---------- */
const Native = {
  handlers: {},
  on(type, fn) { (this.handlers[type] = this.handlers[type] || []).push(fn); return () => { this.handlers[type] = (this.handlers[type] || []).filter(f => f !== fn); }; },
  emit(type, data) { (this.handlers[type] || []).slice().forEach(fn => { try { fn(data); } catch (e) { console.error(e); } }); },
  get available() { return typeof window.Android !== 'undefined' && window.Android !== null; },
  call(name, ...args) { try { if (this.available && typeof window.Android[name] === 'function') return window.Android[name](...args); } catch (e) { console.error(name, e); } return undefined; },
  info() { try { const r = this.call('getInfo'); return r ? JSON.parse(r) : null; } catch (e) { return null; } }
};
window.__native = Native;
Native.on('tts', d => { if (d && d.error === 'lang') toast('صوت اللغة الإنجليزية غير مثبّت في هاتفك (إعدادات ← الإدارة العامة ← تحويل النص إلى كلام)', 4500); else if (d && d.error) toast('تعذّر تشغيل النطق على هذا الهاتف'); });

function speak(text, lang = 'en-US') {
  if (!text) return;
  if (Native.available) { Native.call('speak', String(text), lang); return; }
  try {
    if ('speechSynthesis' in window) { const u = new SpeechSynthesisUtterance(text); u.lang = lang; u.rate = .9; speechSynthesis.cancel(); speechSynthesis.speak(u); return; }
  } catch (e) { /* ignore */ }
  toast('النطق غير متاح هنا');
}
function vibrate(ms = 300) { if (Native.available) Native.call('vibrate', ms); else if (navigator.vibrate) navigator.vibrate(ms); }
function beep() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    const ctx = new AC(); const t0 = ctx.currentTime;
    [0, .25, .5].forEach(off => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine'; o.frequency.value = 880; g.gain.setValueAtTime(.0001, t0 + off);
      g.gain.exponentialRampToValueAtTime(.3, t0 + off + .02); g.gain.exponentialRampToValueAtTime(.0001, t0 + off + .2);
      o.connect(g); g.connect(ctx.destination); o.start(t0 + off); o.stop(t0 + off + .22);
    });
    setTimeout(() => ctx.close && ctx.close(), 1200);
  } catch (e) { /* ignore */ }
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast('تم النسخ'); return; } catch (e) { /* fallback */ }
  try {
    const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); toast('تم النسخ');
  } catch (e) { toast('تعذّر النسخ'); }
}

/* minimal markdown-lite for chat: ```code```, `code`, **bold**, - lists, line breaks */
function mdLite(src) {
  const parts = String(src).split(/```/);
  return parts.map((p, i) => {
    if (i % 2 === 1) { const body = p.replace(/^[a-zA-Z0-9+#-]*\n/, '').replace(/\n$/, ''); return `<pre><code>${esc(body)}</code></pre>`; }
    let h = esc(p);
    h = h.replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>');
    h = h.replace(/^\s*[-•*]\s+/gm, '• ');
    return h.replace(/\n/g, '<br>');
  }).join('');
}
