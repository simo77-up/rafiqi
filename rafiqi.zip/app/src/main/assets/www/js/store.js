'use strict';
/* Local-only storage (WebView localStorage) with an in-memory cache. Nothing leaves the phone. */

const Store = (() => {
  const P = 'rafiqi.v1.';
  const mem = {};
  const cache = {};
  let ok = true;
  try { localStorage.setItem(P + '_t', '1'); localStorage.removeItem(P + '_t'); } catch (e) { ok = false; }

  const clone = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
  const dflt = d => (typeof d === 'function' ? d() : clone(d));

  function get(key, d) {
    if (key in cache) return cache[key];
    let v;
    try {
      const raw = ok ? localStorage.getItem(P + key) : mem[key];
      if (raw != null) v = JSON.parse(raw);
    } catch (e) { v = undefined; }
    if (v === undefined) v = dflt(d);
    cache[key] = v;
    return v;
  }
  function set(key, value) {
    cache[key] = value;
    try {
      const raw = JSON.stringify(value);
      if (ok) localStorage.setItem(P + key, raw); else mem[key] = raw;
    } catch (e) { console.warn('save failed', key, e); if (typeof toast === 'function') toast('تعذّر الحفظ: ذاكرة التطبيق ممتلئة'); }
    return value;
  }
  function update(key, d, fn) {
    const v = get(key, d);
    const r = fn(v);
    return set(key, r === undefined ? v : r);
  }
  function remove(key) { delete cache[key]; try { if (ok) localStorage.removeItem(P + key); else delete mem[key]; } catch (e) { /* ignore */ } }
  function keys() {
    if (!ok) return Object.keys(mem);
    const out = [];
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(P)) out.push(k.slice(P.length)); }
    return out;
  }
  function exportAll() {
    const data = {};
    keys().forEach(k => { data[k] = get(k); });
    return { app: 'rafiqi', version: 1, exportedAt: new Date().toISOString(), data };
  }
  function importAll(obj) {
    if (!obj || obj.app !== 'rafiqi' || typeof obj.data !== 'object') throw new Error('ملف النسخة الاحتياطية غير صالح');
    wipe();
    Object.keys(obj.data).forEach(k => set(k, obj.data[k]));
  }
  function wipe() { keys().forEach(remove); Object.keys(cache).forEach(k => delete cache[k]); }
  return { get, set, update, remove, keys, exportAll, importAll, wipe, get persistent() { return ok; } };
})();

/* ----- settings ----- */
const DEFAULT_SETTINGS = { theme: 'auto', fontScale: 1, newPerDay: 10, focusMin: 25, breakMin: 5, subjects: ['عام', 'اللغة الإنجليزية', 'البرمجة', 'الرياضيات', 'العلوم'], subject: 'عام' };
const Settings = {
  all() { return Object.assign({}, DEFAULT_SETTINGS, Store.get('settings', {})); },
  get(k) { return this.all()[k]; },
  set(k, v) { const s = Store.get('settings', {}); s[k] = v; Store.set('settings', s); this.apply(); },
  apply() {
    const s = this.all(); const root = document.documentElement;
    if (s.theme === 'light' || s.theme === 'dark') root.setAttribute('data-theme', s.theme); else root.removeAttribute('data-theme');
    root.style.setProperty('--fs', String(s.fontScale));
    const meta = document.querySelector('meta[name=theme-color]');
    if (meta) meta.setAttribute('content', s.theme === 'dark' ? '#14201e' : '#0f766e');
  }
};

/* ----- activity / statistics ----- */
const Stats = {
  data() { return Store.get('stats', () => ({ days: {}, focus: {}, reviews: {}, newWords: {}, quizzes: 0, quizBest: 0, tasksDone: 0, sessions: {} })); },
  save(d) { Store.set('stats', d); },
  mark() { const d = this.data(); d.days[isoDate()] = 1; this.save(d); },
  add(field, n = 1, date = isoDate()) { const d = this.data(); d[field] = d[field] || {}; d[field][date] = (d[field][date] || 0) + n; d.days[date] = 1; this.save(d); },
  bump(field, n = 1) { const d = this.data(); d[field] = (d[field] || 0) + n; d.days[isoDate()] = 1; this.save(d); },
  streak() {
    const days = this.data().days; let day = isoDate(); let n = 0;
    if (!days[day]) day = addDays(day, -1);
    while (days[day]) { n++; day = addDays(day, -1); }
    return n;
  },
  last7(field) {
    const d = this.data()[field] || {}; const out = [];
    for (let i = 6; i >= 0; i--) { const day = addDays(isoDate(), -i); out.push({ day, v: d[day] || 0 }); }
    return out;
  },
  today(field) { return (this.data()[field] || {})[isoDate()] || 0; },
  total(field) { return Object.values(this.data()[field] || {}).reduce((a, b) => a + b, 0); }
};
