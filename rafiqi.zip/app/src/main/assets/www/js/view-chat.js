'use strict';
Views.chat = {
  title: 'المساعد الذكي',
  render(el) {
    let mode = Store.get('chatMode', 'general'); if (!AI_MODES[mode]) mode = 'general';
    let busy = false;
    const key = () => 'chat.' + mode;
    const hist = () => Store.get(key(), []);
    el.classList.add('flush');
    el.innerHTML = `<div class="chat-wrap">
      <div class="chat-head"><div class="chips" id="modes"></div>
        <div class="row between"><span id="pill" class="status-pill"></span><button class="btn sm ghost" id="clr">مسح المحادثة</button></div></div>
      <div class="chat-log" id="log"></div>
      <div class="composer"><textarea id="in" rows="1" maxlength="1500"></textarea>
        <button class="send" id="send" aria-label="إرسال"></button></div></div>`;
    const log = $('#log', el), inp = $('#in', el), sendBtn = $('#send', el);

    function pill() {
      AI.refresh();
      const p = $('#pill', el); if (!p) return;
      if (AI.usable) { p.className = 'status-pill ok'; p.innerHTML = '<i></i>' + (AI.state === 'loading' ? 'جارٍ تحميل النموذج…' : 'الذكاء المحلي'); }
      else { p.className = 'status-pill warn'; p.innerHTML = '<i></i>الوضع البسيط (بلا نموذج)'; }
    }
    function modes() {
      $('#modes', el).innerHTML = Object.keys(AI_MODES).map(k => `<button class="chip ${k === mode ? 'on' : ''}" data-m="${k}">${AI_MODES[k].name}</button>`).join('');
      inp.placeholder = AI_MODES[mode].hint;
    }
    function sendIcon() { sendBtn.className = 'send' + (busy && AI.cur ? ' stop' : ''); sendBtn.innerHTML = busy && AI.cur ? icon('stop') : `<span class="flip-x" style="display:flex">${icon('send')}</span>`; }
    function bubble(m, i) {
      const acts = m.role === 'bot' ? `<div class="msg-actions"><button class="round-btn plain" data-copy="${i}" aria-label="نسخ">${icon('copy')}</button>
        ${mode === 'english' || m.speak ? `<button class="round-btn plain" data-say="${i}" aria-label="نطق">${icon('speaker')}</button>` : ''}
        <button class="round-btn plain" data-note="${i}" aria-label="حفظ كملاحظة">${icon('notes')}</button></div>` : '';
      const link = m.link ? `<div class="mt-s"><a href="${esc(m.link[0])}">${esc(m.link[1])}</a></div>` : '';
      return `<div class="msg ${m.role} ${m.err ? 'err' : ''}"><div class="bubble">${mdLite(m.text)}${link}</div>${acts}</div>`;
    }
    function draw() {
      const h = hist();
      log.innerHTML = h.length ? h.map(bubble).join('') :
        `<div class="empty">${icon('chat')}<h3>${AI_MODES[mode].name}</h3><p>${AI.usable ? 'اكتب سؤالك وسأجيبك دون إنترنت.' : 'النموذج الذكي غير مثبّت بعد، فأنا في الوضع البسيط.<br>اكتب «مساعدة» لترى ما أستطيعه، أو ثبّت النموذج من الإعدادات.'}</p></div>`;
      log.scrollTop = log.scrollHeight;
    }
    function autosize() { inp.style.height = 'auto'; inp.style.height = Math.min(120, inp.scrollHeight) + 'px'; }

    async function send() {
      if (busy) { if (AI.cur) AI.stop(); return; }
      const text = inp.value.trim(); if (!text) return;
      inp.value = ''; autosize();
      const h = hist(); const before = h.slice();
      h.push({ role: 'user', text }); Store.set(key(), h.slice(-40)); draw();
      busy = true; sendIcon();
      let node = null;
      const bot = { role: 'bot', text: '' };
      if (AI.usable) {
        log.insertAdjacentHTML('beforeend', `<div class="msg bot"><div class="bubble" id="live"><span class="typing"><i></i><i></i><i></i></span></div></div>`);
        node = $('#live', log); log.scrollTop = log.scrollHeight;
        try {
          const r = await AI.ask(mode, before, text, {
            onStatus: s => { if (node && node.isConnected && !AI.cur.gotToken) node.innerHTML = `<span class="muted small">${esc(s)}</span>`; },
            onToken: t => { if (node && node.isConnected) { node.innerHTML = mdLite(t); log.scrollTop = log.scrollHeight; } }
          });
          bot.text = r.text || '(لا يوجد رد)';
        } catch (e) { bot.text = e.message || 'حدث خطأ'; bot.err = true; }
      } else {
        await sleep(250);
        const r = AI.simple(text); bot.text = r.text; bot.local = true; bot.link = r.link; bot.speak = r.speak;
      }
      const h2 = Store.get(key(), []); h2.push(bot); Store.set(key(), h2.slice(-40));
      Stats.mark(); busy = false;
      if (el.isConnected) { sendIcon(); draw(); }
    }

    el.onclick = e => {
      const m = e.target.closest('[data-m]');
      if (m) { if (busy) return toast('انتظر انتهاء الرد'); mode = m.dataset.m; Store.set('chatMode', mode); modes(); draw(); return; }
      const cp = e.target.closest('[data-copy]'); if (cp) return copyText(hist()[+cp.dataset.copy].text);
      const sy = e.target.closest('[data-say]'); if (sy) { const it = hist()[+sy.dataset.say]; speak(it.speak || it.text.replace(/[؀-ۿ].*$/s, '').slice(0, 400) || it.text); return; }
      const nt = e.target.closest('[data-note]');
      if (nt) { const it = hist()[+nt.dataset.note]; const n = Store.get('notes', []); n.unshift({ id: uid(), title: it.text.slice(0, 40), body: it.text, tags: [], pinned: false, created: Date.now(), updated: Date.now() }); Store.set('notes', n); toast('تم الحفظ في الملاحظات'); return; }
      if (e.target.closest('#clr')) confirmDlg('مسح المحادثة', 'سيتم حذف هذه المحادثة من الهاتف.', 'مسح', true).then(ok => { if (ok) { Store.set(key(), []); draw(); } });
      if (e.target.closest('#send')) send();
    };
    inp.addEventListener('input', autosize);
    inp.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    const off = AI.onChange(() => { pill(); });
    modes(); pill(); sendIcon(); draw();
    return off;
  }
};
