'use strict';
/* Pomodoro timer state lives outside the view so it keeps running while you browse other screens. */
const FocusTimer = {
  mode: 'focus', running: false, endAt: 0, left: 0, total: 0, iv: null, onTick: null, onEnd: null,
  init() { if (!this.total) { this.total = Settings.get('focusMin') * 60; this.left = this.total; } },
  reset(mode) { this.stop(); this.mode = mode || this.mode; this.total = (this.mode === 'focus' ? Settings.get('focusMin') : Settings.get('breakMin')) * 60; this.left = this.total; },
  start() { this.init(); this.running = true; this.endAt = Date.now() + this.left * 1000; Native.call('keepScreenOn', true); clearInterval(this.iv); this.iv = setInterval(() => this.tick(), 500); },
  stop() { this.running = false; clearInterval(this.iv); Native.call('keepScreenOn', false); if (this.endAt) this.left = Math.max(0, Math.round((this.endAt - Date.now()) / 1000)); },
  tick() {
    this.left = Math.max(0, Math.round((this.endAt - Date.now()) / 1000));
    if (this.onTick) this.onTick();
    if (this.left <= 0) {
      const wasFocus = this.mode === 'focus', mins = Math.round(this.total / 60);
      this.stop(); beep(); vibrate(600);
      if (wasFocus) { Stats.add('focus', mins); toast('أحسنت! انتهت جلسة التركيز 🎉', 4000); }
      this.reset(wasFocus ? 'break' : 'focus'); this.endAt = 0;
      if (this.onEnd) this.onEnd();
    }
  }
};

Views.study = {
  title: 'الدراسة',
  render(el, rest) {
    let tab = rest[0] || 'tasks', subj = 'all';
    const T = [['tasks', 'المهام'], ['timer', 'التركيز'], ['cards', 'بطاقاتي'], ['stats', 'الإحصاءات']];
    let off = null;
    const body = () => $('#body', el);
    const shell = () => { el.innerHTML = `<div class="seg">${T.map(t => `<button data-t="${t[0]}" class="${t[0] === tab ? 'on' : ''}">${t[1]}</button>`).join('')}</div><div id="body"></div>`; };

    function tasks() {
      const all = Store.get('tasks', []); const subjects = Settings.get('subjects');
      const list = all.filter(t => subj === 'all' || t.subject === subj).sort((a, b) => (a.done - b.done) || (b.pri - a.pri) || ((a.due || '9') < (b.due || '9') ? -1 : 1));
      const today = isoDate();
      body().innerHTML = `
        <div class="card"><label class="field"><span>مهمة جديدة</span><input type="text" id="nt" placeholder="مثال: مراجعة درس القواعد" maxlength="120"></label>
          <div class="grid2"><select id="ns">${subjects.map(s => `<option ${s === Settings.get('subject') ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select>
          <input type="date" id="nd"></div>
          <button class="btn block mt" data-a="add">${icon('plus')} إضافة</button></div>
        <div class="chips"><button class="chip ${subj === 'all' ? 'on' : ''}" data-s="all">الكل</button>${subjects.map(s => `<button class="chip ${subj === s ? 'on' : ''}" data-s="${esc(s)}">${esc(s)}</button>`).join('')}</div>
        <div class="card">${list.length ? list.map(t => `<div class="list-item"><button class="check ${t.done ? 'on' : ''}" data-chk="${t.id}" aria-label="إنجاز">${icon('check')}</button>
          <div class="grow"><div class="task-title ${t.done ? 'done' : ''}">${esc(t.title)}</div><div class="tiny muted">${esc(t.subject)}${t.due ? ' · ' + fmtShort(t.due) : ''} ${t.due && !t.done && t.due < today ? '<span class="badge bad">متأخرة</span>' : ''}</div></div>
          <button class="round-btn plain" data-del="${t.id}" aria-label="حذف">${icon('trash')}</button></div>`).join('') : `<div class="empty">${icon('list')}<p>لا توجد مهام. أضف أول مهمة!</p></div>`}</div>`;
    }
    function timer() {
      FocusTimer.init(); const f = FocusTimer; const C = 2 * Math.PI * 110;
      body().innerHTML = `<div class="card center"><div class="seg" style="justify-content:center"><button data-fm="focus" class="${f.mode === 'focus' ? 'on' : ''}">تركيز ${Settings.get('focusMin')}د</button><button data-fm="break" class="${f.mode === 'break' ? 'on' : ''}">استراحة ${Settings.get('breakMin')}د</button></div>
        <div class="ring ${f.mode === 'break' ? 'break' : ''}"><svg viewBox="0 0 250 250"><circle class="bg" cx="125" cy="125" r="110"/><circle class="fg" id="fg" cx="125" cy="125" r="110" stroke-dasharray="${C}" stroke-dashoffset="0"/></svg>
        <div class="time"><b id="tm"></b><span>${f.mode === 'focus' ? 'وقت التركيز' : 'وقت الراحة'}</span></div></div>
        <div class="grid2"><button class="btn" id="tgo"></button><button class="btn ghost" data-a="treset">إعادة</button></div>
        <p class="muted small mt">اليوم: ${Stats.today('focus')} دقيقة تركيز. الشاشة تبقى مضاءة أثناء العدّ.</p></div>`;
      const upd = () => {
        const tm = $('#tm', el); if (!tm) return;
        tm.textContent = mmss(f.running ? f.left : f.left);
        $('#fg', el).style.strokeDashoffset = String(C * (1 - f.left / f.total));
        $('#tgo', el).innerHTML = f.running ? icon('pause') + ' إيقاف مؤقت' : icon('play') + ' ابدأ';
      };
      f.onTick = upd; f.onEnd = () => { if (el.isConnected && tab === 'timer') timer(); }; upd();
    }
    function cardsTab() {
      const cs = Store.get('cards', []); const its = cs.map(c => ({ id: 'c:' + c.id, front: c.front, back: c.back, tag: c.subject }));
      const c = SRS.counts(its); const subjects = Settings.get('subjects');
      body().innerHTML = `<div class="card"><h3>بطاقة جديدة</h3>
        <label class="field"><span>الوجه الأمامي (سؤال)</span><input type="text" id="cf" maxlength="200"></label>
        <label class="field"><span>الخلفية (جواب)</span><textarea id="cb" rows="2" maxlength="400"></textarea></label>
        <select id="cs" class="mb">${subjects.map(s => `<option>${esc(s)}</option>`).join('')}</select>
        <button class="btn block" data-a="addcard">${icon('plus')} حفظ البطاقة</button></div>
        <button class="btn block mb" data-a="rev" ${(c.due + c.fresh) ? '' : 'disabled'}>${icon('cards')} مراجعة (${c.due + c.fresh})</button>
        <div class="card">${cs.length ? cs.map(x => `<div class="list-item"><div class="grow"><b>${esc(x.front)}</b><div class="muted small">${esc(x.back)}</div></div><button class="round-btn plain" data-delc="${x.id}">${icon('trash')}</button></div>`).join('') : `<div class="empty">${icon('cards')}<p>أنشئ بطاقاتك الخاصة للمراجعة المتباعدة.</p></div>`}</div>`;
    }
    function statsTab() {
      const bar = (arr, unit) => { const mx = Math.max(1, ...arr.map(x => x.v)); return `<div class="bars">${arr.map(x => `<div class="bar ${x.day === isoDate() ? 'today' : ''}"><span>${x.v || ''}</span><i style="height:${Math.round(x.v * 90 / mx)}%"></i><span>${WEEKDAYS[parseIso(x.day).getDay()].slice(0, 3)}</span></div>`).join('')}</div><div class="tiny muted center">${unit}</div>`; };
      const tasks = Store.get('tasks', []), c = SRS.counts(VOCAB);
      body().innerHTML = `<div class="grid3 mb"><div class="stat"><b>${Stats.streak()}</b><span>أيام متواصلة</span></div><div class="stat"><b>${Stats.total('focus')}</b><span>دقائق تركيز</span></div><div class="stat"><b>${Stats.total('reviews')}</b><span>مراجعات</span></div></div>
        <div class="card"><h3>التركيز آخر 7 أيام</h3>${bar(Stats.last7('focus'), 'دقائق')}</div>
        <div class="card"><h3>مراجعة البطاقات آخر 7 أيام</h3>${bar(Stats.last7('reviews'), 'بطاقات')}</div>
        <div class="card"><div class="kv"><span>كلمات متقنة</span><b>${c.mastered} / ${c.total}</b></div><div class="kv"><span>مهام منجزة</span><b>${tasks.filter(t => t.done).length} / ${tasks.length}</b></div><div class="kv"><span>اختبارات</span><b>${Stats.data().quizzes || 0}</b></div></div>`;
    }
    function draw() { FocusTimer.onTick = null; FocusTimer.onEnd = null; shell(); ({ tasks, timer, cards: cardsTab, stats: statsTab }[tab] || tasks)(); }

    el.onclick = e => {
      const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; draw(); return; }
      const s = e.target.closest('[data-s]'); if (s) { subj = s.dataset.s; tasks(); return; }
      const chk = e.target.closest('[data-chk]'); if (chk) { const all = Store.get('tasks', []); const it = all.find(x => x.id === chk.dataset.chk); if (it) { it.done = !it.done; if (it.done) Stats.bump('tasksDone'); Store.set('tasks', all); Stats.mark(); } tasks(); return; }
      const del = e.target.closest('[data-del]'); if (del) { Store.set('tasks', Store.get('tasks', []).filter(x => x.id !== del.dataset.del)); tasks(); return; }
      const dc = e.target.closest('[data-delc]'); if (dc) { Store.set('cards', Store.get('cards', []).filter(x => x.id !== dc.dataset.delc)); SRS.forget(['c:' + dc.dataset.delc]); cardsTab(); return; }
      const fm = e.target.closest('[data-fm]'); if (fm) { FocusTimer.reset(fm.dataset.fm); timer(); return; }
      if (e.target.closest('#tgo')) { FocusTimer.running ? FocusTimer.stop() : FocusTimer.start(); timer(); return; }
      const a = e.target.closest('[data-a]'); if (!a) return;
      const k = a.dataset.a;
      if (k === 'add') { const v = $('#nt', el).value.trim(); if (!v) return toast('اكتب عنوان المهمة'); const all = Store.get('tasks', []); all.unshift({ id: uid(), title: v, subject: $('#ns', el).value, due: $('#nd', el).value, pri: 1, done: false, created: Date.now() }); Store.set('tasks', all); Stats.mark(); tasks(); }
      else if (k === 'treset') { FocusTimer.reset(); timer(); }
      else if (k === 'addcard') { const f = $('#cf', el).value.trim(), b = $('#cb', el).value.trim(); if (!f || !b) return toast('املأ الوجهين'); const cs = Store.get('cards', []); cs.unshift({ id: uid(), front: f, back: b, subject: $('#cs', el).value }); Store.set('cards', cs); toast('تمت إضافة البطاقة'); cardsTab(); }
      else if (k === 'rev') { const its = Store.get('cards', []).map(c => ({ id: 'c:' + c.id, front: c.front, back: c.back, tag: c.subject })); body().innerHTML = '<div id="sess"></div>'; SRS.mount($('#sess', el), { items: its, newLimit: 50, statField: 'newCards', frontLtr: false, onDone: cardsTab }); }
    };
    draw();
    return () => { FocusTimer.onTick = null; FocusTimer.onEnd = null; };
  }
};
