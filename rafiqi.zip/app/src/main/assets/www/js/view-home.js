'use strict';
Views.home = {
  title: 'رفيقي',
  render(el) {
    AI.refresh();
    const c = SRS.counts(VOCAB), w = AI.wordOfDay();
    const open = Store.get('tasks', []).filter(t => !t.done).length;
    const hr = new Date().getHours();
    const greet = hr < 12 ? 'صباح الخير' : hr < 18 ? 'مرحباً' : 'مساء الخير';
    const aiOk = AI.usable;
    el.innerHTML = `
      <div class="hero"><h2>${greet} 👋</h2><p>${fmtDate(isoDate())}</p>
        <div class="row mt-s wrap"><span class="chip">${icon('flame', 16)} ${Stats.streak()} يوم متواصل</span>
        <span class="chip">${aiOk ? 'الذكاء المحلي جاهز' : 'الوضع البسيط'}</span></div></div>
      <div class="grid3 mb">
        <div class="stat"><b>${c.due + Math.min(c.fresh, Math.max(0, Settings.get('newPerDay') - Stats.today('newWords')))}</b><span>بطاقات اليوم</span></div>
        <div class="stat"><b>${open}</b><span>مهام مفتوحة</span></div>
        <div class="stat"><b>${Stats.today('focus')}</b><span>دقائق تركيز</span></div></div>
      <div class="card"><div class="row between"><div><span class="badge warn">كلمة اليوم</span>
        <h3 class="ltr mt-s" style="font-size:1.4rem">${esc(w.en)}</h3><div>${esc(w.ar)}</div><div class="muted small ltr">${esc(w.ex)}</div></div>
        <button class="round-btn" data-say="${esc(w.en)}" aria-label="نطق">${icon('speaker')}</button></div></div>
      <div class="grid2">
        ${[['chat', 'chat', 'المساعد الذكي', 'اسأل واكتب وتعلّم'], ['english', 'english', 'تعلّم الإنجليزية', 'مفردات وقواعد'], ['study', 'timer', 'الدراسة', 'مهام ومؤقّت تركيز'], ['code', 'code', 'البرمجة', 'دروس ومحرّر يعمل دون اتصال'], ['notes', 'notes', 'الملاحظات', 'دوّن أفكارك'], ['settings', 'gear', 'الإعدادات', 'النموذج والنسخ الاحتياطي']]
          .map(t => `<button class="tile" data-go="#/${t[0]}"><span class="ti">${icon(t[1])}</span><b>${t[2]}</b><span>${t[3]}</span></button>`).join('')}
      </div>
      <p class="muted small center mt">${icon('lock', 14)} بياناتك محفوظة على هاتفك فقط، والتطبيق بلا إذن إنترنت.</p>`;
    el.onclick = e => {
      const g = e.target.closest('[data-go]'); if (g) { location.hash = g.dataset.go; return; }
      const s = e.target.closest('[data-say]'); if (s) speak(s.dataset.say);
    };
  }
};
