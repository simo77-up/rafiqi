'use strict';
/* Programming course data. JavaScript and HTML run offline inside the app; Python is reading-only. */

const CODE_LESSONS = [
  { id: 'js1', lang: 'js', title: 'المتغيّرات: let و const',
    intro: ['المتغيّر صندوق له اسم نخزّن فيه قيمة. استخدم <b>const</b> للقيمة التي لا تتغيّر، و<b>let</b> للقيمة التي ستتغيّر.',
      'دالة <b>console.log</b> تطبع النتيجة في نافذة المخرجات أسفل المحرّر.'],
    code: `const name = "Sara";
let age = 20;
age = age + 1;
console.log(name + " is " + age);` },
  { id: 'js2', lang: 'js', title: 'الأنواع والعمليات',
    intro: ['أهم الأنواع: <b>number</b> للأرقام، <b>string</b> للنصوص، <b>boolean</b> لقيم صح/خطأ (true / false).',
      'استخدم <b>typeof</b> لمعرفة النوع، وعلامة الاقتباس المائلة ` ` لدمج المتغيّرات داخل النص.'],
    code: `const price = 25;
const qty = 3;
const total = price * qty;
console.log(typeof total, total);
console.log(\`Total: \${total} MAD\`);
console.log("5" + 2, 5 + 2);`, },
  { id: 'js3', lang: 'js', title: 'الشروط if / else',
    intro: ['الشرط يتيح للبرنامج أن يقرّر. الشرط يُكتب بين قوسين، والعمليات المقارنة: <b>===</b> تساوي، <b>!==</b> اختلاف، <b>&gt;</b> أكبر، <b>&lt;</b> أصغر.',
      'استخدم <b>&amp;&amp;</b> للـ "و" و<b>||</b> للـ "أو".'],
    code: `const score = 72;
if (score >= 90) {
  console.log("Excellent");
} else if (score >= 60) {
  console.log("Good, keep going");
} else {
  console.log("Try again");
}` },
  { id: 'js4', lang: 'js', title: 'الحلقات for و while',
    intro: ['الحلقة تكرّر الأوامر. <b>for</b> مناسبة عندما نعرف عدد التكرارات، و<b>while</b> عندما نكرّر حتى يتحقق شرط.',
      'جرّب تغيير الرقم 5 إلى 10 وانظر النتيجة.'],
    code: `let sum = 0;
for (let i = 1; i <= 5; i++) {
  sum += i;
  console.log("i =", i, "sum =", sum);
}
let n = 3;
while (n > 0) {
  console.log("countdown", n);
  n--;
}` },
  { id: 'js5', lang: 'js', title: 'الدوال Functions',
    intro: ['الدالة مجموعة أوامر لها اسم نستدعيها متى شئنا، وتستقبل مدخلات (parameters) وتُرجع نتيجة بـ <b>return</b>.',
      'الصيغة المختصرة <b>=&gt;</b> تسمّى arrow function.'],
    code: `function square(x) {
  return x * x;
}
const add = (a, b) => a + b;
console.log(square(7));
console.log(add(2, 3));` },
  { id: 'js6', lang: 'js', title: 'المصفوفات Arrays',
    intro: ['المصفوفة قائمة مرتّبة من القيم، وأول عنصر رقمه <b>0</b>.',
      'أدوات مهمة: <b>push</b> للإضافة، <b>map</b> لتحويل كل عنصر، <b>filter</b> لاختيار عناصر، <b>reduce</b> للجمع.'],
    code: `const nums = [4, 8, 15, 16, 23, 42];
nums.push(50);
const doubled = nums.map(n => n * 2);
const big = nums.filter(n => n > 20);
const total = nums.reduce((a, b) => a + b, 0);
console.log(doubled);
console.log(big);
console.log("total:", total, "first:", nums[0]);` },
  { id: 'js7', lang: 'js', title: 'الكائنات Objects',
    intro: ['الكائن يجمع معلومات مترابطة على شكل <b>مفتاح: قيمة</b>. نصل إليها بالنقطة: user.name.',
      'يمكن وضع كائنات داخل مصفوفة لتمثيل قائمة (طلاب، منتجات، ...).'],
    code: `const user = { name: "Omar", age: 25, skills: ["JS", "English"] };
console.log(user.name, user.skills.length);
user.city = "Casablanca";
const people = [user, { name: "Lina", age: 22, skills: [] }];
people.forEach(p => console.log(p.name, p.age));
console.log(JSON.stringify(user));` },
  { id: 'js8', lang: 'js', title: 'تمرين: FizzBuzz',
    intro: ['مسألة شهيرة في المقابلات: اطبع الأرقام من 1 إلى 15، وبدل المضاعف لـ 3 اكتب <b>Fizz</b>، ولـ 5 اكتب <b>Buzz</b>، ولكليهما <b>FizzBuzz</b>.',
      'علامة <b>%</b> تعطي باقي القسمة.'],
    code: `for (let i = 1; i <= 15; i++) {
  if (i % 15 === 0) console.log("FizzBuzz");
  else if (i % 3 === 0) console.log("Fizz");
  else if (i % 5 === 0) console.log("Buzz");
  else console.log(i);
}` },
  { id: 'js9', lang: 'js', title: 'تمرين: هل العدد أولي؟',
    intro: ['العدد الأولي يقبل القسمة على 1 ونفسه فقط. نختبر القواسم حتى الجذر التربيعي للعدد.'],
    code: `function isPrime(n) {
  if (n < 2) return false;
  for (let i = 2; i * i <= n; i++) {
    if (n % i === 0) return false;
  }
  return true;
}
const primes = [];
for (let n = 1; n <= 30; n++) if (isPrime(n)) primes.push(n);
console.log(primes.join(", "));` },
  { id: 'html1', lang: 'html', title: 'HTML: أول صفحة',
    intro: ['صفحة الويب تُبنى بوسوم (tags): <b>h1</b> عنوان، <b>p</b> فقرة، <b>ul / li</b> قائمة، <b>button</b> زر.',
      'اضغط "تشغيل" لتظهر المعاينة أسفل المحرّر.'],
    code: `<h1>مرحباً بالعالم</h1>
<p>هذه صفحتي الأولى.</p>
<ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>JavaScript</li>
</ul>` },
  { id: 'html2', lang: 'html', title: 'CSS: الألوان والتنسيق',
    intro: ['نضيف التنسيق داخل وسم <b>style</b>: اللون color، الخلفية background، الهوامش padding، الحواف border-radius.'],
    code: `<style>
  body { font-family: sans-serif; background: #f4f7f6; padding: 20px; }
  .card { background: white; padding: 16px; border-radius: 16px;
          box-shadow: 0 2px 10px rgba(0,0,0,.1); }
  h2 { color: #0f766e; margin-top: 0; }
</style>
<div class="card">
  <h2>بطاقة</h2>
  <p>تنسيق بسيط بـ CSS.</p>
</div>` },
  { id: 'html3', lang: 'html', title: 'HTML + JS: زر تفاعلي',
    intro: ['نربط الصفحة بالبرمجة: عند الضغط على الزر ننفّذ دالة تغيّر النص.'],
    code: `<button id="b" style="font-size:18px;padding:10px 18px">اضغطني</button>
<p id="out">العدّاد: 0</p>
<script>
  let n = 0;
  document.getElementById("b").onclick = () => {
    n++;
    document.getElementById("out").textContent = "العدّاد: " + n;
  };
</script>` }
];

/* Python reference cards: read-only (running Python needs an interpreter that is not bundled). */
const PY_CARDS = [
  { title: 'الطباعة والمتغيّرات', code: `name = "Sara"\nage = 20\nprint(name, age)\nprint(f"{name} is {age}")`, note: 'لا نحتاج إلى let أو const؛ نكتب الاسم وقيمته مباشرة. النص المنسّق يبدأ بـ f.' },
  { title: 'الشروط', code: `score = 72\nif score >= 90:\n    print("Excellent")\nelif score >= 60:\n    print("Good")\nelse:\n    print("Try again")`, note: 'بدل الأقواس المعقوفة نستخدم النقطتين : والمسافة البادئة (4 مسافات).' },
  { title: 'الحلقات', code: `for i in range(1, 6):\n    print(i)\n\nn = 3\nwhile n > 0:\n    print(n)\n    n -= 1`, note: 'range(1, 6) تعطي 1 إلى 5 (الرقم الأخير غير داخل).' },
  { title: 'الدوال', code: `def square(x):\n    return x * x\n\nprint(square(7))`, note: 'نعرّف الدالة بـ def.' },
  { title: 'القوائم والقواميس', code: `nums = [4, 8, 15]\nnums.append(16)\ndoubled = [n * 2 for n in nums]\nuser = {"name": "Omar", "age": 25}\nprint(doubled, user["name"])`, note: 'القائمة list تشبه المصفوفة، والقاموس dict يشبه الكائن في JavaScript.' }
];

const CODE_TEMPLATES = [
  { name: 'ترحيب بسيط', lang: 'js', code: 'const name = "Rafiqi";\nconsole.log(`Hello, ${name}!`);' },
  { name: 'جدول الضرب', lang: 'js', code: 'for (let i = 1; i <= 10; i++) {\n  console.log(`7 x ${i} = ${7 * i}`);\n}' },
  { name: 'صفحة HTML فارغة', lang: 'html', code: '<h1>عنوان</h1>\n<p>اكتب هنا...</p>' }
];

const SYMBOLS = ['{', '}', '(', ')', '[', ']', ';', '=', '"', "'", '`', '<', '>', '/', '+', '-', '*', '&', '|', '!', ':', '.', ',', '$', '_', '\\', '  '];
