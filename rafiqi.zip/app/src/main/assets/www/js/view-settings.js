'use strict';
Views.settings = {
  title: 'الإعدادات',
  render(el) {
    let imp = null; // import progress
    const offs = [];
    function draw() {
      const info = AI.refresh() || {}; const s = Settings.all();
      const native = Native.available;
      const arm64 = !native || (info.abis || []).indexOf('arm64-v8a') >= 0;
      el.innerHTML = `
      <div class="card"><h3>${icon('spark', 20)} الذكاء الاصطناعي المحلي</h3>
        ${!native ? '<p class="muted small">أنت تشاهد نسخة المعاينة؛ النموذج يعمل داخل تطبيق Android فقط.</p>' : ''}
        <div class="kv"><span>الحالة</span><b>${info.modelInstalled ? (AI.state === 'ready' ? 'جاهز' : AI.state === 'loading' ? 'قيد التحميل…' : AI.state === 'error' ? 'خطأ' : 'مثبّت') : 'غير مثبّت'}</b></div>
        ${info.modelInstalled ? `<div class="kv"><span>حجم الملف</span><b>${info.modelMB} MB</b></div>` : ''}
        ${native ? `<div class="kv"><span>الجهاز</span><b>${esc(info.device || '')}</b></div><div class="kv"><span>الذاكرة (RAM)</span><b>${info.totalRamMB} MB</b></div><div class="kv"><span>مساحة فارغة</span><b>${info.freeMB} MB</b></div>` : ''}
        ${!arm64 ? '<p class="badge bad">معمارية هذا الجهاز غير مدعومة (يلزم arm64)</p>' : ''}
        ${AI.state === 'error' ? `<p class="badge bad" style="white-space:normal">${esc(AI.stateDetail)}</p>` : ''}
        ${imp ? `<div class="mt"><div class="progress"><i style="width:${Math.max(3, imp.pct)}%"></i></div><div class="small muted mt-s">${imp.pct >= 0 ? imp.pct + '%' : ''} (${imp.mb} MB) — لا تغلق التطبيق</div></div>` : ''}
        <div class="grid2 mt"><button class="btn" data-a="import" ${native && !imp ? '' : 'disabled'}>${icon('upload')} استيراد النموذج</button>
        <button class="btn ghost" data-a="load" ${info.modelInstalled ? '' : 'disabled'}>${icon('bolt')} تحميل الآن</button></div>
        ${info.modelInstalled ? `<button class="btn danger ghost block mt-s" data-a="rmmodel">${icon('trash')} حذف ملف النموذج</button>` : ''}
        <details class="mt"><summary class="small" style="font-weight:700">كيف أحصل على ملف النموذج؟</summary>
          <ol class="small muted" style="padding-inline-start:20px">
          <li>مرة واحدة فقط وأنت متصل بالإنترنت: افتح من متصفح الهاتف صفحة <span class="ltr">huggingface.co/litert-community/Qwen2.5-0.5B-Instruct</span></li>
          <li>من «Files and versions» نزّل الملف <span class="ltr">Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task</span> (حوالي 547 MB).</li>
          <li>ارجع هنا واضغط «استيراد النموذج» واختر الملف من «التنزيلات».</li>
          <li>بعد الاستيراد يعمل كل شيء دون إنترنت وحتى في وضع الطيران.</li></ol></details></div>

      <div class="card"><h3>المظهر</h3>
        <div class="seg">${[['auto', 'تلقائي'], ['light', 'فاتح'], ['dark', 'داكن']].map(t => `<button data-theme="${t[0]}" class="${s.theme === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>
        <label class="field"><span>حجم الخط: ${Math.round(s.fontScale * 100)}%</span><input type="range" id="fs" min="0.85" max="1.4" step="0.05" value="${s.fontScale}" style="width:100%"></label></div>

      <div class="card"><h3>التعلّم والتركيز</h3>
        <label class="field"><span>كلمات جديدة يومياً</span><input type="number" id="npd" min="1" max="50" value="${s.newPerDay}"></label>
        <div class="grid2"><label class="field"><span>التركيز (دقيقة)</span><input type="number" id="fmin" min="5" max="90" value="${s.focusMin}"></label>
        <label class="field"><span>الاستراحة (دقيقة)</span><input type="number" id="bmin" min="1" max="30" value="${s.breakMin}"></label></div></div>

      <div class="card"><h3>النسخ الاحتياطي</h3><p class="muted small">يحفظ ملاحظاتك ومهامك وتقدّمك في ملف JSON تخزّنه حيث تشاء.</p>
        <div class="grid2"><button class="btn soft" data-a="export">${icon('download')} حفظ نسخة</button><button class="btn soft" data-a="restore">${icon('upload')} استعادة</button></div>
        <button class="btn danger ghost block mt-s" data-a="wipe">${icon('trash')} مسح كل البيانات</button></div>

      <div class="card"><h3>${icon('lock', 20)} الخصوصية واختبار وضع الطيران</h3>
        <p class="small muted">التطبيق لا يملك إذن الإنترنت أصلاً، فلا يستطيع إرسال أي شيء. لتجربة ذلك فعّل وضع الطيران ثم افتح المساعد واسأله سؤالاً.</p>
        <div class="kv"><span>حالة المتصفّح</span><b id="onl">${navigator.onLine ? 'متصل بالشبكة' : 'لا اتصال'}</b></div>
        <div class="kv"><span>الإصدار</span><b>${esc(info.version || '1.0')}</b></div></div>`;
    }
    const onProg = d => {
      if (d.status === 'progress') imp = { pct: d.pct, mb: d.mb };
      else if (d.status === 'done') { imp = null; toast('تم استيراد النموذج ✓'); if (Native.available) Native.call('loadModel'); }
      else if (d.status === 'error') { imp = null; toast(d.message || 'فشل الاستيراد', 5000); }
      else imp = null;
      if (el.isConnected) { const sc = $('#view').scrollTop; draw(); $('#view').scrollTop = sc; }
    };
    offs.push(Native.on('modelImport', onProg));
    offs.push(Native.on('backupSaved', d => toast(d.ok ? 'تم حفظ النسخة ✓' : (d.message || 'فشل الحفظ'))));
    offs.push(Native.on('backupData', async d => {
      if (!d.ok) return toast(d.message || 'فشل القراءة');
      try { const o = JSON.parse(d.json); if (await confirmDlg('استعادة نسخة', 'سيتم استبدال بياناتك الحالية.', 'استعادة', true)) { Store.importAll(o); Settings.apply(); toast('تمت الاستعادة ✓'); draw(); } }
      catch (e) { toast('ملف غير صالح'); }
    }));
    offs.push(AI.onChange(() => { if (el.isConnected && !imp) { const sc = $('#view').scrollTop; draw(); $('#view').scrollTop = sc; } }));

    el.onclick = async e => {
      const th = e.target.closest('[data-theme]'); if (th) { Settings.set('theme', th.dataset.theme); draw(); return; }
      const a = e.target.closest('[data-a]'); if (!a) return; const k = a.dataset.a;
      if (k === 'import') Native.call('pickModel');
      else if (k === 'load') { toast('جارٍ تحميل النموذج…'); Native.call('loadModel'); }
      else if (k === 'rmmodel') { if (await confirmDlg('حذف النموذج', 'سيعود التطبيق إلى الوضع البسيط. يمكنك استيراده مجدداً.', 'حذف', true)) { Native.call('deleteModel'); AI.state = 'idle'; draw(); } }
      else if (k === 'export') { const j = JSON.stringify(Store.exportAll()); if (Native.available) Native.call('saveBackup', j, 'rafiqi-backup-' + isoDate() + '.json'); else copyText(j); }
      else if (k === 'restore') Native.call('pickBackup');
      else if (k === 'wipe') { if (await confirmDlg('مسح كل البيانات', 'سيتم حذف الملاحظات والمهام والتقدّم نهائياً. (ملف النموذج لا يُحذف)', 'مسح الكل', true)) { Store.wipe(); Settings.apply(); toast('تم المسح'); draw(); } }
    };
    el.addEventListener('change', e => {
      if (e.target.id === 'fs') Settings.set('fontScale', parseFloat(e.target.value));
      else if (e.target.id === 'npd') Settings.set('newPerDay', clamp(parseInt(e.target.value) || 10, 1, 50));
      else if (e.target.id === 'fmin') { Settings.set('focusMin', clamp(parseInt(e.target.value) || 25, 5, 90)); FocusTimer.reset(); }
      else if (e.target.id === 'bmin') { Settings.set('breakMin', clamp(parseInt(e.target.value) || 5, 1, 30)); FocusTimer.reset(); }
    });
    const onl = () => { const o = $('#onl'); if (o) o.textContent = navigator.onLine ? 'متصل بالشبكة' : 'لا اتصال'; };
    window.addEventListener('online', onl); window.addEventListener('offline', onl);
    draw();
    return () => { offs.forEach(f => f()); window.removeEventListener('online', onl); window.removeEventListener('offline', onl); };
  }
};
