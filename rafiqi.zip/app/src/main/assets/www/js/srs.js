'use strict';
/* Spaced repetition (Leitner boxes) + the flashcard session UI, shared by English words and custom cards. */

const SRS = {
  INTERVALS: [0, 1, 2, 4, 8, 16, 32],

  all() { return Store.get('srs', {}); },
  stateOf(id) { return this.all()[id] || null; },
  isDue(id) { const s = this.stateOf(id); return !!s && s.box > 0 && s.due <= isoDate(); },
  isMastered(id) { const s = this.stateOf(id); return !!s && s.box >= 5; },

  grade(id, ok) {
    const all = this.all();
    const s = all[id] || { box: 0, ok: 0, bad: 0 };
    const today = isoDate();
    if (ok) { s.box = Math.min(6, (s.box || 0) + 1); s.ok++; s.due = addDays(today, this.INTERVALS[s.box]); }
    else { s.box = 1; s.bad++; s.due = today; }
    s.last = today;
    all[id] = s;
    Store.set('srs', all);
    return s;
  },
  forget(ids) { const all = this.all(); ids.forEach(id => delete all[id]); Store.set('srs', all); },

  counts(items) {
    let due = 0, fresh = 0, learning = 0, mastered = 0;
    items.forEach(it => {
      const s = this.stateOf(it.id);
      if (!s) fresh++; else { if (s.box >= 5) mastered++; else learning++; if (s.box > 0 && s.due <= isoDate()) due++; }
    });
    return { due, fresh, learning, mastered, total: items.length };
  },

  queue(items, { newLimit = 10, statField = 'newWords', max = 20, forceNew = false } = {}) {
    const today = isoDate();
    const due = items.filter(it => this.isDue(it.id)).sort((a, b) => this.stateOf(a.id).due.localeCompare(this.stateOf(b.id).due));
    const fresh = items.filter(it => !this.stateOf(it.id));
    const allowed = forceNew ? 10 : Math.max(0, newLimit - Stats.today(statField));
    return due.slice(0, max).concat(fresh.slice(0, allowed)).slice(0, max);
  },

  /**
   * Run a review session inside `el`.
   * opts: { items, newLimit, statField, forceNew, frontLtr, onDone }
   * item: { id, front, back, ex?, tag?, speak? }
   */
  mount(el, opts) {
    const { items, newLimit = 10, statField = 'newWords', forceNew = false, frontLtr = true, onDone } = opts;
    let queue = this.queue(items, { newLimit, statField, forceNew });
    const total = queue.length;
    let idx = 0, revealed = false, okN = 0, badN = 0;
    const requeued = new Set();

    const finish = () => {
      Stats.mark();
      const pct = (okN + badN) ? Math.round(okN * 100 / (okN + badN)) : 0;
      el.innerHTML = `<div class="card center">
        <div style="font-size:3rem">🎉</div>
        <h3>انتهت الجلسة</h3>
        <p class="muted">راجعت ${countAr(okN + badN, 'بطاقة', 'بطاقتين', 'بطاقات', 'بطاقة')} — الإجابات الصحيحة ${okN} (${pct}%)</p>
        <button class="btn block mt" data-a="done">رجوع</button></div>`;
      el.querySelector('[data-a=done]').onclick = () => onDone && onDone();
    };

    const draw = () => {
      if (idx >= queue.length) return finish();
      const it = queue[idx];
      const isNew = !this.stateOf(it.id);
      const prog = Math.round(idx * 100 / Math.max(1, queue.length));
      el.innerHTML = `
        <div class="row between mb"><span class="muted small">${idx + 1} / ${queue.length}</span>
          <span class="badge ${isNew ? 'warn' : ''}">${isNew ? 'جديدة' : 'مراجعة'}</span></div>
        <div class="progress mb"><i style="width:${prog}%"></i></div>
        <div class="fc-wrap"><div class="flashcard flip-in" id="fc">
          ${it.tag ? `<span class="badge tag">${esc(it.tag)}</span>` : ''}
          <div class="front ${frontLtr ? '' : 'ar'}">${esc(it.front)}</div>
          ${it.speak ? `<button class="round-btn" data-a="say" aria-label="نطق">${icon('speaker')}</button>` : ''}
          ${revealed ? `<hr style="width:60%;border:0;border-top:1.5px dashed var(--line)"><div class="back">${esc(it.back)}</div>${it.ex ? `<div class="ex">${esc(it.ex)}</div>` : ''}` : '<div class="muted small mt-s">حاول أن تتذكّر المعنى ثم اكشف الجواب</div>'}
        </div></div>
        ${revealed
          ? `<div class="fc-actions"><button class="btn bad" data-a="no">لم أعرفها</button><button class="btn good" data-a="yes">عرفتها</button></div>`
          : `<button class="btn block mt" style="min-height:56px" data-a="show">اعرض الجواب</button>`}`;
    };

    el.onclick = e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a; const it = queue[idx];
      if (a === 'show') { revealed = true; draw(); if (it.speak && opts.autoSpeakOnReveal) speak(it.speak); }
      else if (a === 'say') { speak(it.speak); }
      else if (a === 'yes' || a === 'no') {
        const ok = a === 'yes';
        const wasNew = !this.stateOf(it.id);
        this.grade(it.id, ok);
        Stats.add('reviews', 1);
        if (wasNew) Stats.add(statField, 1);
        if (ok) okN++; else { badN++; if (!requeued.has(it.id)) { requeued.add(it.id); queue.push(it); } }
        idx++; revealed = false; draw();
      }
    };

    if (!queue.length) {
      el.innerHTML = `<div class="empty">${icon('check')}<h3>لا توجد بطاقات مستحقة الآن</h3><p>أحسنت! عُد لاحقاً أو أضف كلمات جديدة.</p></div>
        <button class="btn block" data-a="done">رجوع</button>`;
      el.onclick = e => { if (e.target.closest('[data-a=done]') && onDone) onDone(); };
      return;
    }
    draw();
  }
};
