'use strict';
/* Offline code lab: JavaScript runs in a Web Worker (killed after 5 s), HTML in a sandboxed iframe. */
function runJS(code, onLine, onDone) {
  const src = `
    const __fmt = a => { try { return typeof a === 'string' ? a : (typeof a === 'undefined' ? 'undefined' : JSON.stringify(a, (k, v) => typeof v === 'function' ? '[Function]' : v)); } catch (e) { return String(a); } };
    const console = { log: (...a) => postMessage({ t: 'l', v: a.map(__fmt).join(' ') }), error: (...a) => postMessage({ t: 'e', v: a.map(__fmt).join(' ') }), warn: (...a) => postMessage({ t: 'w', v: a.map(__fmt).join(' ') }) };
    try { const __r = (function () { ${code}\n })(); if (__r !== undefined) postMessage({ t: 'r', v: __fmt(__r) }); } catch (e) { postMessage({ t: 'e', v: e.name + ': ' + e.message }); }
    postMessage({ t: 'd' });`;
  let w, url, finished = false;
  const end = msg => { if (finished) return; finished = true; try { w.terminate(); } catch (e) { /* ignore */ } try { URL.revokeObjectURL(url); } catch (e) { /* ignore */ } if (msg) onLine('e', msg); onDone(); };
  try { url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' })); w = new Worker(url); }
  catch (e) { onLine('e', 'تعذّر تشغيل المحرّك: ' + e.message); onDone(); return () => { }; }
  const timer = setTimeout(() => end('⏱ توقّف التنفيذ بعد 5 ثوانٍ (ربما حلقة لا نهائية).'), 5000);
  w.onmessage = e => { const m = e.data; if (m.t === 'd') { clearTimeout(timer); end(); } else onLine(m.t, m.v); };
  w.onerror = e => { clearTimeout(timer); end('خطأ: ' + e.message); };
  return () => { clearTimeout(timer); end(); };
}

Views.code = {
  title: 'البرمجة',
  render(el, rest) {
    let tab = rest[0] || 'lessons', cur = null, lang = 'js', code = Store.get('codeDraft', { js: CODE_TEMPLATES[0].code, html: CODE_TEMPLATES[2].code });
    let stopRun = null;
    const T = [['lessons', 'الدروس'], ['editor', 'المحرّر'], ['python', 'بايثون']];
    const body = () => $('#body', el);
    const shell = () => { el.innerHTML = `<div class="seg">${T.map(t => `<button data-t="${t[0]}" class="${t[0] === tab ? 'on' : ''}">${t[1]}</button>`).join('')}</div><div id="body"></div>`; };
    const saveDraft = debounce(() => Store.set('codeDraft', code), 400);

    function lessons() {
      const done = Store.get('codeDone', {});
      const n = CODE_LESSONS.filter(l => done[l.id]).length;
      body().innerHTML = `<div class="card"><div class="row between"><b>تقدّمك</b><span class="badge">${n} / ${CODE_LESSONS.length}</span></div><div class="progress mt-s"><i style="width:${n * 100 / CODE_LESSONS.length}%"></i></div></div>
        <div class="card">${CODE_LESSONS.map((l, i) => `<button class="lesson-row" data-l="${l.id}"><span class="num ${done[l.id] ? 'done' : ''}">${done[l.id] ? icon('check', 18) : i + 1}</span><span class="grow"><b>${l.title}</b><div class="tiny muted">${l.lang === 'js' ? 'JavaScript' : 'HTML / CSS'}</div></span>${icon('back')}</button>`).join('')}</div>`;
    }
    function editor() {
      const les = cur ? CODE_LESSONS.find(l => l.id === cur) : null;
      body().innerHTML = `${les ? `<div class="card"><h3>${les.title}</h3>${les.intro.map(p => `<p>${p}</p>`).join('')}</div>` : ''}
        <div class="seg"><button data-lang="js" class="${lang === 'js' ? 'on' : ''}">JavaScript</button><button data-lang="html" class="${lang === 'html' ? 'on' : ''}">HTML</button></div>
        <textarea id="code" class="code-area" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" rows="12"></textarea>
        <div class="sym-bar">${SYMBOLS.map(s => `<button data-sym="${esc(s)}">${esc(s.trim() || '⇥')}</button>`).join('')}</div>
        <div class="grid2"><button class="btn" data-a="run">${icon('play')} تشغيل</button><button class="btn ghost" data-a="reset">${les ? 'استعادة الدرس' : 'قالب جديد'}</button></div>
        <div class="mt" id="outwrap"><div class="console" id="out"><span class="d">اضغط «تشغيل» لرؤية النتيجة هنا</span></div></div>
        ${les ? `<button class="btn soft block mt" data-a="done">${icon('check')} أنهيت هذا الدرس</button>` : ''}
        <button class="btn ghost block mt-s" data-a="ask">${icon('chat')} اطلب شرح الكود من المساعد</button>`;
      $('#code', el).value = code[lang]; $('#code', el).addEventListener('input', ev => { code[lang] = ev.target.value; saveDraft(); });
    }
    function python() {
      body().innerHTML = `<div class="card flat"><p class="muted small">تشغيل بايثون يحتاج مفسّراً غير مضمّن في هذا الإصدار، لذلك هذه بطاقات مرجعية للقراءة والمقارنة مع JavaScript (يمكنك نسخ الكود).</p></div>` +
        PY_CARDS.map(c => `<div class="card"><h3>${c.title}</h3><div class="code-block">${esc(c.code)}</div><p class="muted small">${c.note}</p><button class="btn sm ghost" data-copyc="${esc(c.code)}">${icon('copy')} نسخ</button></div>`).join('');
    }
    function print(t, v) { const o = $('#out', el); if (!o) return; if (o.querySelector('.d')) o.innerHTML = ''; o.insertAdjacentHTML('beforeend', `<div class="${t === 'e' ? 'e' : t === 'w' ? 'w' : t === 'r' ? 'r' : ''}">${t === 'r' ? '⮕ ' : ''}${esc(v)}</div>`); o.scrollTop = o.scrollHeight; }
    function run() {
      if (stopRun) { stopRun(); stopRun = null; }
      const wrap = $('#outwrap', el);
      if (lang === 'html') {
        wrap.innerHTML = `<iframe class="preview-frame" sandbox="allow-scripts"></iframe>`;
        $('iframe', wrap).srcdoc = `<!doctype html><html dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body>${code.html}</body></html>`;
        Stats.mark(); return;
      }
      wrap.innerHTML = '<div class="console" id="out"><span class="d">جارٍ التشغيل…</span></div>';
      let any = false;
      stopRun = runJS(code.js, (t, v) => { any = true; print(t, v); }, () => { if (!any) { const o = $('#out', el); if (o) o.innerHTML = '<span class="d">(لا توجد مخرجات — استخدم console.log)</span>'; } stopRun = null; });
      Stats.mark();
    }
    function draw() { shell(); ({ lessons, editor, python }[tab] || lessons)(); }

    el.onclick = e => {
      const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; draw(); return; }
      const l = e.target.closest('[data-l]'); if (l) { const les = CODE_LESSONS.find(x => x.id === l.dataset.l); cur = les.id; lang = les.lang; code[lang] = les.code; tab = 'editor'; draw(); $('#view').scrollTop = 0; return; }
      const lg = e.target.closest('[data-lang]'); if (lg) { lang = lg.dataset.lang; editor(); return; }
      const sy = e.target.closest('[data-sym]');
      if (sy) { const ta = $('#code', el), s = sy.dataset.sym, a = ta.selectionStart, b = ta.selectionEnd; ta.value = ta.value.slice(0, a) + s + ta.value.slice(b); ta.selectionStart = ta.selectionEnd = a + s.length; ta.focus(); code[lang] = ta.value; saveDraft(); return; }
      const cc = e.target.closest('[data-copyc]'); if (cc) { copyText(cc.dataset.copyc); return; }
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'run') run();
      else if (a.dataset.a === 'reset') { const les = cur && CODE_LESSONS.find(x => x.id === cur); code[lang] = les && les.lang === lang ? les.code : (lang === 'js' ? CODE_TEMPLATES[0].code : CODE_TEMPLATES[2].code); editor(); }
      else if (a.dataset.a === 'done') { const d = Store.get('codeDone', {}); d[cur] = 1; Store.set('codeDone', d); Stats.mark(); toast('أحسنت! ✓'); }
      else if (a.dataset.a === 'ask') { Store.set('chatMode', 'code'); const h = Store.get('chat.code', []); h.push({ role: 'user', text: 'اشرح لي هذا الكود:\n```\n' + code[lang].slice(0, 700) + '\n```' }); Store.set('chat.code', h); toast('افتح المساعد وأرسل سؤالك'); location.hash = '#/chat'; }
    };
    draw();
    return () => { if (stopRun) stopRun(); };
  }
};
