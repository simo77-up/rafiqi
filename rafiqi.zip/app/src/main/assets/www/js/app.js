'use strict';
/* Router + tab bar. Views register themselves in `Views`. */
const TABS = [['home', 'الرئيسية', 'home'], ['chat', 'المساعد', 'chat'], ['english', 'الإنجليزية', 'english'], ['study', 'الدراسة', 'study'], ['code', 'البرمجة', 'code'], ['notes', 'ملاحظات', 'notes']];
let viewCleanup = null;

function buildTabs() {
  $('#tabbar').innerHTML = TABS.map(t => `<a class="tab" data-tab="${t[0]}" href="#/${t[0]}"><span class="tab-ic">${icon(t[2])}</span>${t[1]}</a>`).join('');
}

function route() {
  const parts = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  const name = Views[parts[0]] ? parts[0] : 'home';
  const rest = parts.slice(1);
  if (viewCleanup) { try { viewCleanup(); } catch (e) { /* ignore */ } viewCleanup = null; }
  const v = Views[name];
  const view = $('#view');
  view.className = ''; view.innerHTML = ''; view.scrollTop = 0;
  $('#title').textContent = typeof v.title === 'function' ? v.title(rest) : v.title;
  $$('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  $('#btn-back').hidden = !(name === 'settings');
  $('#btn-settings').hidden = name === 'settings';
  try { viewCleanup = v.render(view, rest) || null; }
  catch (e) { console.error(e); view.innerHTML = `<div class="card"><h3>حدث خطأ</h3><p class="muted ltr">${esc(e.message)}</p></div>`; }
}

window.addEventListener('hashchange', route);
window.addEventListener('DOMContentLoaded', () => {
  Settings.apply();
  $('#btn-settings').innerHTML = icon('gear');
  $('#btn-back').innerHTML = icon('back');
  $('#btn-settings').onclick = () => { location.hash = '#/settings'; };
  $('#btn-back').onclick = () => { location.hash = '#/home'; };
  buildTabs();
  AI.refresh();
  if (AI.usable && Native.available) Native.call('loadModel');
  if (!location.hash) location.hash = '#/home'; else route();
  Stats.mark();
});
